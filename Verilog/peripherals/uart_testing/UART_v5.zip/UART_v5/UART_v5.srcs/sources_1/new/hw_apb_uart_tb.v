`timescale 1ns / 1ps

module hw_apb_uart_tb (
    input  wire clk,           // 50 MHz FPGA clock
    input  wire rst,           // Active-high reset
    input  wire rx,            // RX input
    output wire tx_out,        // To PC
    output wire tx_busy_led    // Status LED
);

    // APB / CPU Interface Signals
    reg  [31:0] cpu_paddr;
    reg  [31:0] cpu_wdata;
    reg         cpu_write;
    wire        apb_done;
    wire [31:0] cpu_rdata;
    
    // Unused Peripheral Interface Signals
    wire [4:0]  irq;
    wire        pwm_out0, pwm_out1;
    wire [31:0] gpio_out, gpio_oe;
    wire [3:0]  qspi_io_out;
    wire        qspi_io_oe, qspi_sck, qspi_cs_n;

    apb_interface dut (
        .clk(clk), .resetn(~rst),
        .pclk(clk), .presetn(~rst), 
        .pready(1'b1), .prdata(32'b0), .pslverr(1'b0), 
        .cpu_paddr(cpu_paddr), .cpu_wdata(cpu_wdata), .write(cpu_write),
        .apb_done(apb_done), .cpu_rdata(cpu_rdata),
        .irq(irq), .pwm_out0(pwm_out0), .pwm_out1(pwm_out1),
        .gpio_in(32'b0), .gpio_out(gpio_out), .gpio_oe(gpio_oe),
        .rx(rx), .tx(tx_out), 
        .qspi_io_in(4'b0), .qspi_io_out(qspi_io_out), 
        .qspi_io_oe(qspi_io_oe), .qspi_sck(qspi_sck), .qspi_cs_n(qspi_cs_n)
    );

    // UART Memory Map (Base = 0x2040)
    localparam UART_TDR = 32'h0000_2048; // Offset 0x08
    localparam UART_CR1 = 32'h0000_204C; // Offset 0x0C
    localparam UART_BRR = 32'h0000_2050; // Offset 0x10

    // Character Generation
    reg [5:0] char_idx; 
    reg [7:0] current_char;

    always @(*) begin
        if (char_idx < 26)
            current_char = 8'h61 + char_idx;          // 'a' - 'z'
        else if (char_idx < 35)
            current_char = 8'h31 + (char_idx - 26);   // '1' - '9'
        else
            current_char = 8'h41 + (char_idx - 35);   // 'A' - 'Z'
    end

    // FSM States
    localparam CFG_BRR    = 4'd0;
    localparam WAIT_BRR   = 4'd1;
    localparam CFG_CR1    = 4'd2;
    localparam WAIT_CR1   = 4'd3;
    localparam SEND_CHAR  = 4'd4;
    localparam WAIT_APB   = 4'd5;
    localparam WAIT_TX    = 4'd6;
    localparam DONE       = 4'd7;

    reg [3:0] state;
    reg [15:0] delay_cnt; 

    always @(posedge clk) begin
        if (rst) begin
            state     <= CFG_BRR;
            cpu_paddr <= 32'b0;
            cpu_wdata <= 32'b0;
            cpu_write <= 1'b0;
            char_idx  <= 0;
            delay_cnt <= 0;
        end else begin
            cpu_paddr <= 32'b0;
            
            case (state)
                CFG_BRR: begin
                    cpu_paddr <= UART_BRR;
                    cpu_wdata <= 32'h0000_001B; // 27 decimal for 115200 baud
                    cpu_write <= 1'b1;
                    state     <= WAIT_BRR;
                end

                WAIT_BRR: begin
                    if (apb_done) begin
                        cpu_write <= 1'b0;
                        state     <= CFG_CR1;
                    end /*else begin
                        cpu_paddr <= UART_BRR;
                    end*/
                end

                CFG_CR1: begin
                    cpu_paddr <= UART_CR1;
                    cpu_wdata <= 32'h0000_0003; // CR1 = 3 (UE=1, TE=1)
                    cpu_write <= 1'b1;
                    state     <= WAIT_CR1;
                end

                WAIT_CR1: begin
                    if (apb_done) begin
                        cpu_write <= 1'b0;
                        state     <= SEND_CHAR;
                    end /*else begin
                        cpu_paddr <= UART_CR1;
                    end*/
                end

                SEND_CHAR: begin
                    cpu_paddr <= UART_TDR;
                    cpu_wdata <= {24'b0, current_char};
                    cpu_write <= 1'b1;
                    state     <= WAIT_APB;
                end

                WAIT_APB: begin
                    if (apb_done) begin
                        cpu_write <= 1'b0;
                        // Hardware delay for 115200 baud (approx 4340 clocks per 10-bit frame at 50MHz)
                        delay_cnt <= 16'd5000; 
                        state     <= WAIT_TX;
                    end /*else begin
                        cpu_paddr <= UART_TDR; 
                    end*/
                end

                WAIT_TX: begin
                    if (delay_cnt == 0) begin
                        if (char_idx == 60) state <= DONE;
                        else begin
                            char_idx <= char_idx + 1;
                            state    <= SEND_CHAR;
                        end
                    end else begin
                        delay_cnt <= delay_cnt - 1;
                    end
                end

                DONE: begin
                    // Stay here. Pulse reset to restart.
                end
            endcase
        end
    end

    assign tx_busy_led = (state != DONE);

endmodule