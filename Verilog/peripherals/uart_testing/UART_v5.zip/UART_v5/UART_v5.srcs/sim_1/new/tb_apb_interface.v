`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09.04.2026 21:29:40
// Design Name: 
// Module Name: tb_apb_interface
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb_apb_interface();

    // Parameters
    localparam CLK_FREQ = 50_000_000;
    localparam BAUD_RATE = 115200;
    localparam BIT_PERIOD = 8681; // 10^9 / 115200

    // UART Register Addresses (Based on your offset map)
    localparam ADDR_SR  = 32'h0000_2040;
    localparam ADDR_TDR = 32'h0000_2048; // Ensure TDR is at 0x08 offset in uart_top
    localparam ADDR_CR1 = 32'h0000_204C; // Ensure CR1 is at 0x0C offset in uart_top
    localparam ADDR_BRR = 32'h0000_2050; // Ensure BRR is at 0x10 offset in uart_top

    localparam [15:0] BRR_VALUE = (CLK_FREQ + (BAUD_RATE * 8)) / (BAUD_RATE * 16);

    // System Signals
    reg clk;
    reg resetn;

    // CPU Interface Signals
    reg  [31:0] cpu_paddr;
    reg  [31:0] cpu_wdata;
    reg         cpu_write;
    wire        apb_done;
    wire [31:0] cpu_rdata;

    // Peripheral Pads
    wire        tx;
    reg         rx;
    wire [4:0]  irq;
    wire        pwm_out0, pwm_out1;
    wire [31:0] gpio_out, gpio_oe;
    wire [3:0]  qspi_io_out;
    wire        qspi_io_oe, qspi_sck, qspi_cs_n;

    // Instantiate the APB Interface Wrapper
    apb_interface uut (
        .clk(clk),              .resetn(resetn),
        .pclk(clk),             .presetn(resetn),
        
        // External APB inputs (ignored by internal mux, tied to safe values)
        .pready(1'b1), .prdata(32'd0), .pslverr(1'b0),
        
        // APB external outputs (left unconnected for simulation)
        .paddr(), .psel(), .penable(), .pwrite(), .pwdata(),

        // CPU Interface
        .cpu_paddr(cpu_paddr),
        .cpu_wdata(cpu_wdata),
        .write(cpu_write),
        .apb_done(apb_done),
        .cpu_rdata(cpu_rdata),

        // Peripherals
        .irq(irq),
        .pwm_out0(pwm_out0), .pwm_out1(pwm_out1),
        .gpio_in(32'd0), .gpio_out(gpio_out), .gpio_oe(gpio_oe),
        .rx(rx), .tx(tx),
        .qspi_io_in(4'd0), .qspi_io_out(qspi_io_out), .qspi_io_oe(qspi_io_oe),
        .qspi_sck(qspi_sck), .qspi_cs_n(qspi_cs_n)
    );

    // --- Clock Generation (50 MHz) ---
    initial begin
        clk = 0;
        forever #10 clk = ~clk; 
    end

    // --- CPU Bus Tasks ---
    // These tasks abstract the bus handshaking, acting exactly like the CPU
    task write_reg(input [31:0] addr, input [31:0] data);
        begin
            @(posedge clk);
            cpu_paddr = addr;
            cpu_wdata = data;
            cpu_write = 1'b1;
            
            // Wait for APB interface to finish transaction
            while (!apb_done) @(posedge clk);
            
            // Clear bus to prevent re-triggering
            cpu_paddr = 32'd0;
            cpu_write = 1'b0;
            @(posedge clk); // Give IDLE state 1 cycle to settle
        end
    endtask

    task read_reg(input [31:0] addr, output [31:0] data);
        begin
            @(posedge clk);
            cpu_paddr = addr;
            cpu_write = 1'b0; // Read request
            
            // Wait for APB interface to finish transaction
            while (!apb_done) @(posedge clk);
            
            // Capture data
            data = cpu_rdata;
            
            // Clear bus
            cpu_paddr = 32'd0;
            @(posedge clk); // Give IDLE state 1 cycle to settle
        end
    endtask

    // --- Main CPU Simulation Sequence ---
    reg [31:0] read_val;

    initial begin
        // Init Inputs
        resetn = 0;
        cpu_paddr = 0;
        cpu_wdata = 0;
        cpu_write = 0;
        rx = 1;

        $display("[%0t] Resetting System...", $time);
        #100;
        resetn = 1;
        #100;

        $display("[%0t] Configuring UART...", $time);
        // 1. Set Baud Rate Register
        write_reg(ADDR_BRR, BRR_VALUE);
        
        // 2. Enable UART (UE=1, TE=1, RE=0) -> 0x03
        write_reg(ADDR_CR1, 32'h03);

        // 3. Send "O"
        $display("[%0t] CPU polling TXE to send 'O'...", $time);
        read_reg(ADDR_SR, read_val);
        while ((read_val & 32'h1) == 0) begin // Poll bit 0 (TXE)
            read_reg(ADDR_SR, read_val);
        end
        write_reg(ADDR_TDR, "O");

        // 4. Send "K"
        $display("[%0t] CPU polling TXE to send 'K'...", $time);
        read_reg(ADDR_SR, read_val);
        while ((read_val & 32'h1) == 0) begin 
            read_reg(ADDR_SR, read_val);
        end
        write_reg(ADDR_TDR, "K");
        
        // Wait for final character to finish shifting out over TX pin
        #500_000;
        $display("[%0t] Simulation Finished.", $time);
        $finish;
    end

    // --- Auto-Decoder Task (Monitors physical TX pin) ---
    reg [7:0] received_char;
    integer i;

    always begin
        @(negedge tx); // Wait for Start Bit
        #(BIT_PERIOD / 2); // Center of start bit
        
        if (tx == 0) begin 
            #(BIT_PERIOD); // Center of first data bit
            
            for (i = 0; i < 8; i = i + 1) begin
                received_char[i] = tx;
                #(BIT_PERIOD);
            end
            
            if (tx == 1) begin
                $display("\n>>> UART DECODED: '%c' (Hex: %h) at %0t <<<\n", received_char, received_char, $time);
            end else begin
                $display("\n>>> ERROR: Framing Error <<<\n");
            end
        end
    end

endmodule