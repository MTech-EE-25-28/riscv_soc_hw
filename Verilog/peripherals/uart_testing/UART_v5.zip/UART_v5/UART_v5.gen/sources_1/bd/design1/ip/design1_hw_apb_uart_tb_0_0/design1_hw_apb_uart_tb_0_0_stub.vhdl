-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Thu Apr  9 22:57:16 2026
-- Host        : DELL-LAPTOP running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               e:/vlsi26/UART_v5/UART_v5.gen/sources_1/bd/design1/ip/design1_hw_apb_uart_tb_0_0/design1_hw_apb_uart_tb_0_0_stub.vhdl
-- Design      : design1_hw_apb_uart_tb_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design1_hw_apb_uart_tb_0_0 is
  Port ( 
    clk : in STD_LOGIC;
    rst : in STD_LOGIC;
    rx : in STD_LOGIC;
    tx_out : out STD_LOGIC;
    tx_busy_led : out STD_LOGIC
  );

end design1_hw_apb_uart_tb_0_0;

architecture stub of design1_hw_apb_uart_tb_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,rst,rx,tx_out,tx_busy_led";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "hw_apb_uart_tb,Vivado 2020.2";
begin
end;
