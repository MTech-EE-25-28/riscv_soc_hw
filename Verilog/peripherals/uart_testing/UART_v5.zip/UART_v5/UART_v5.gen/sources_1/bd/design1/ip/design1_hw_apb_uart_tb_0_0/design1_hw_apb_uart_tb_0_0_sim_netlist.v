// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Thu Apr  9 22:57:16 2026
// Host        : DELL-LAPTOP running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               e:/vlsi26/UART_v5/UART_v5.gen/sources_1/bd/design1/ip/design1_hw_apb_uart_tb_0_0/design1_hw_apb_uart_tb_0_0_sim_netlist.v
// Design      : design1_hw_apb_uart_tb_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design1_hw_apb_uart_tb_0_0,hw_apb_uart_tb,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "hw_apb_uart_tb,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design1_hw_apb_uart_tb_0_0
   (clk,
    rst,
    rx,
    tx_out,
    tx_busy_led);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst, FREQ_HZ 50000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 rst RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME rst, POLARITY ACTIVE_HIGH, INSERT_VIP 0" *) input rst;
  input rx;
  output tx_out;
  output tx_busy_led;

  wire clk;
  wire rst;
  wire tx_busy_led;
  wire tx_out;

  design1_hw_apb_uart_tb_0_0_hw_apb_uart_tb inst
       (.clk(clk),
        .rst(rst),
        .tx_busy_led(tx_busy_led),
        .tx_out(tx_out));
endmodule

(* ORIG_REF_NAME = "UART_module" *) 
module design1_hw_apb_uart_tb_0_0_UART_module
   (tx_out,
    Q,
    clk,
    rst,
    \TDR_reg_reg[6]_0 ,
    \CR1_reg_reg[0]_0 ,
    \CR1_reg_reg[0]_1 ,
    \CR1_reg_reg[0]_2 );
  output tx_out;
  input [3:0]Q;
  input clk;
  input rst;
  input [6:0]\TDR_reg_reg[6]_0 ;
  input \CR1_reg_reg[0]_0 ;
  input \CR1_reg_reg[0]_1 ;
  input \CR1_reg_reg[0]_2 ;

  wire [6:0]BRR_reg;
  wire \CR1_reg[5]_i_2_n_0 ;
  wire \CR1_reg_reg[0]_0 ;
  wire \CR1_reg_reg[0]_1 ;
  wire \CR1_reg_reg[0]_2 ;
  wire \CR1_reg_reg_n_0_[0] ;
  wire \CR1_reg_reg_n_0_[1] ;
  wire \FSM_sequential_tx_state[0]_i_2_n_0 ;
  wire \FSM_sequential_tx_state[1]_i_2_n_0 ;
  wire \FSM_sequential_tx_state[2]_i_2_n_0 ;
  wire \FSM_sequential_tx_state[2]_i_3_n_0 ;
  wire M;
  wire PCE;
  wire PS;
  wire [3:0]Q;
  wire [6:0]TDR_reg;
  wire \TDR_reg[6]_i_1_n_0 ;
  wire \TDR_reg[6]_i_2_n_0 ;
  wire [6:0]\TDR_reg_reg[6]_0 ;
  wire baud_gen_inst_n_0;
  wire baud_gen_inst_n_1;
  wire baud_gen_inst_n_2;
  wire baud_gen_inst_n_3;
  wire baud_gen_inst_n_4;
  wire baud_gen_inst_n_5;
  wire baud_gen_inst_n_6;
  wire baud_gen_inst_n_7;
  wire brr_en_wire;
  wire clk;
  wire cr_en_wire;
  wire rst;
  wire [0:0]sr_out_wire;
  wire [3:0]tx_bit_ptr;
  wire \tx_bit_ptr[0]_i_1_n_0 ;
  wire \tx_bit_ptr[1]_i_1_n_0 ;
  wire \tx_bit_ptr[2]_i_1_n_0 ;
  wire \tx_bit_ptr[3]_i_2_n_0 ;
  wire \tx_bit_ptr[3]_i_4_n_0 ;
  wire \tx_bit_ptr[3]_i_5_n_0 ;
  wire tx_i_2_n_0;
  wire tx_i_3_n_0;
  wire tx_i_4_n_0;
  wire tx_i_6_n_0;
  wire tx_i_7_n_0;
  wire tx_i_8_n_0;
  wire tx_i_9_n_0;
  wire tx_out;
  wire \tx_s_tick_cnt[0]_i_1_n_0 ;
  wire \tx_s_tick_cnt[1]_i_1_n_0 ;
  wire \tx_s_tick_cnt[2]_i_1_n_0 ;
  wire \tx_s_tick_cnt[2]_i_2_n_0 ;
  wire \tx_s_tick_cnt[3]_i_2_n_0 ;
  wire \tx_s_tick_cnt[3]_i_3_n_0 ;
  wire \tx_s_tick_cnt[3]_i_4_n_0 ;
  wire \tx_s_tick_cnt_reg_n_0_[0] ;
  wire \tx_s_tick_cnt_reg_n_0_[1] ;
  wire \tx_s_tick_cnt_reg_n_0_[2] ;
  wire \tx_s_tick_cnt_reg_n_0_[3] ;
  wire [6:0]tx_shift_reg;
  wire [2:0]tx_state__0;
  wire txe_flag_i_2_n_0;

  LUT4 #(
    .INIT(16'h0800)) 
    \BRR_reg[6]_i_1 
       (.I0(\TDR_reg[6]_i_2_n_0 ),
        .I1(Q[3]),
        .I2(Q[1]),
        .I3(Q[2]),
        .O(brr_en_wire));
  FDCE \BRR_reg_reg[0] 
       (.C(clk),
        .CE(brr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [0]),
        .Q(BRR_reg[0]));
  FDCE \BRR_reg_reg[1] 
       (.C(clk),
        .CE(brr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [1]),
        .Q(BRR_reg[1]));
  FDCE \BRR_reg_reg[2] 
       (.C(clk),
        .CE(brr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [2]),
        .Q(BRR_reg[2]));
  FDCE \BRR_reg_reg[3] 
       (.C(clk),
        .CE(brr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [3]),
        .Q(BRR_reg[3]));
  FDCE \BRR_reg_reg[4] 
       (.C(clk),
        .CE(brr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [4]),
        .Q(BRR_reg[4]));
  FDCE \BRR_reg_reg[5] 
       (.C(clk),
        .CE(brr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [5]),
        .Q(BRR_reg[5]));
  FDCE \BRR_reg_reg[6] 
       (.C(clk),
        .CE(brr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [6]),
        .Q(BRR_reg[6]));
  LUT5 #(
    .INIT(32'h00008000)) 
    \CR1_reg[5]_i_1 
       (.I0(\CR1_reg_reg[0]_0 ),
        .I1(\CR1_reg_reg[0]_1 ),
        .I2(\CR1_reg_reg[0]_2 ),
        .I3(Q[0]),
        .I4(\CR1_reg[5]_i_2_n_0 ),
        .O(cr_en_wire));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hDF)) 
    \CR1_reg[5]_i_2 
       (.I0(Q[1]),
        .I1(Q[2]),
        .I2(Q[3]),
        .O(\CR1_reg[5]_i_2_n_0 ));
  FDCE \CR1_reg_reg[0] 
       (.C(clk),
        .CE(cr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [0]),
        .Q(\CR1_reg_reg_n_0_[0] ));
  FDCE \CR1_reg_reg[1] 
       (.C(clk),
        .CE(cr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [1]),
        .Q(\CR1_reg_reg_n_0_[1] ));
  FDCE \CR1_reg_reg[3] 
       (.C(clk),
        .CE(cr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [3]),
        .Q(M));
  FDCE \CR1_reg_reg[4] 
       (.C(clk),
        .CE(cr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [4]),
        .Q(PCE));
  FDCE \CR1_reg_reg[5] 
       (.C(clk),
        .CE(cr_en_wire),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [5]),
        .Q(PS));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \FSM_sequential_tx_state[0]_i_2 
       (.I0(tx_state__0[1]),
        .I1(PCE),
        .O(\FSM_sequential_tx_state[0]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \FSM_sequential_tx_state[1]_i_2 
       (.I0(\CR1_reg_reg_n_0_[1] ),
        .I1(\CR1_reg_reg_n_0_[0] ),
        .O(\FSM_sequential_tx_state[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h4F)) 
    \FSM_sequential_tx_state[2]_i_2 
       (.I0(tx_state__0[0]),
        .I1(PCE),
        .I2(tx_state__0[1]),
        .O(\FSM_sequential_tx_state[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFCECEFFFFCECE0)) 
    \FSM_sequential_tx_state[2]_i_3 
       (.I0(\tx_bit_ptr[3]_i_5_n_0 ),
        .I1(\tx_bit_ptr[3]_i_4_n_0 ),
        .I2(tx_state__0[1]),
        .I3(tx_state__0[0]),
        .I4(tx_state__0[2]),
        .I5(sr_out_wire),
        .O(\FSM_sequential_tx_state[2]_i_3_n_0 ));
  (* FSM_ENCODED_STATES = "TX_IDLE:000,TX_START:001,TX_DATA:010,TX_STOP:100,TX_PARITY:011" *) 
  FDCE \FSM_sequential_tx_state_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .CLR(rst),
        .D(baud_gen_inst_n_2),
        .Q(tx_state__0[0]));
  (* FSM_ENCODED_STATES = "TX_IDLE:000,TX_START:001,TX_DATA:010,TX_STOP:100,TX_PARITY:011" *) 
  FDCE \FSM_sequential_tx_state_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .CLR(rst),
        .D(baud_gen_inst_n_1),
        .Q(tx_state__0[1]));
  (* FSM_ENCODED_STATES = "TX_IDLE:000,TX_START:001,TX_DATA:010,TX_STOP:100,TX_PARITY:011" *) 
  FDCE \FSM_sequential_tx_state_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .CLR(rst),
        .D(baud_gen_inst_n_0),
        .Q(tx_state__0[2]));
  LUT6 #(
    .INIT(64'h2000000000000000)) 
    \TDR_reg[6]_i_1 
       (.I0(Q[1]),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(\TDR_reg[6]_i_2_n_0 ),
        .I4(\CR1_reg_reg_n_0_[0] ),
        .I5(\CR1_reg_reg_n_0_[1] ),
        .O(\TDR_reg[6]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0080)) 
    \TDR_reg[6]_i_2 
       (.I0(\CR1_reg_reg[0]_0 ),
        .I1(\CR1_reg_reg[0]_1 ),
        .I2(\CR1_reg_reg[0]_2 ),
        .I3(Q[0]),
        .O(\TDR_reg[6]_i_2_n_0 ));
  FDCE \TDR_reg_reg[0] 
       (.C(clk),
        .CE(\TDR_reg[6]_i_1_n_0 ),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [0]),
        .Q(TDR_reg[0]));
  FDCE \TDR_reg_reg[1] 
       (.C(clk),
        .CE(\TDR_reg[6]_i_1_n_0 ),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [1]),
        .Q(TDR_reg[1]));
  FDCE \TDR_reg_reg[2] 
       (.C(clk),
        .CE(\TDR_reg[6]_i_1_n_0 ),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [2]),
        .Q(TDR_reg[2]));
  FDCE \TDR_reg_reg[3] 
       (.C(clk),
        .CE(\TDR_reg[6]_i_1_n_0 ),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [3]),
        .Q(TDR_reg[3]));
  FDCE \TDR_reg_reg[4] 
       (.C(clk),
        .CE(\TDR_reg[6]_i_1_n_0 ),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [4]),
        .Q(TDR_reg[4]));
  FDCE \TDR_reg_reg[5] 
       (.C(clk),
        .CE(\TDR_reg[6]_i_1_n_0 ),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [5]),
        .Q(TDR_reg[5]));
  FDCE \TDR_reg_reg[6] 
       (.C(clk),
        .CE(\TDR_reg[6]_i_1_n_0 ),
        .CLR(rst),
        .D(\TDR_reg_reg[6]_0 [6]),
        .Q(TDR_reg[6]));
  design1_hw_apb_uart_tb_0_0_baud_rate_gen baud_gen_inst
       (.\CR1_reg_reg[4] (baud_gen_inst_n_1),
        .E(baud_gen_inst_n_3),
        .\FSM_sequential_tx_state_reg[0] (baud_gen_inst_n_7),
        .\FSM_sequential_tx_state_reg[0]_0 (\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .\FSM_sequential_tx_state_reg[1] (baud_gen_inst_n_4),
        .\FSM_sequential_tx_state_reg[1]_0 (\FSM_sequential_tx_state[1]_i_2_n_0 ),
        .\FSM_sequential_tx_state_reg[2] (baud_gen_inst_n_2),
        .\FSM_sequential_tx_state_reg[2]_0 (baud_gen_inst_n_5),
        .\FSM_sequential_tx_state_reg[2]_1 (baud_gen_inst_n_6),
        .\FSM_sequential_tx_state_reg[2]_2 (\FSM_sequential_tx_state[2]_i_2_n_0 ),
        .\FSM_sequential_tx_state_reg[2]_3 (\FSM_sequential_tx_state[2]_i_3_n_0 ),
        .Q({PCE,\CR1_reg_reg_n_0_[1] ,\CR1_reg_reg_n_0_[0] }),
        .baud_tick_reg_0(baud_gen_inst_n_0),
        .baud_tick_reg_1(BRR_reg),
        .clk(clk),
        .rst(rst),
        .sr_out_wire(sr_out_wire),
        .\tx_bit_ptr_reg[0] (\tx_bit_ptr[3]_i_4_n_0 ),
        .\tx_bit_ptr_reg[0]_0 (\tx_bit_ptr[3]_i_5_n_0 ),
        .tx_out(tx_out),
        .tx_reg(tx_i_2_n_0),
        .tx_reg_0(tx_i_3_n_0),
        .tx_reg_1(tx_i_4_n_0),
        .tx_state__0(tx_state__0),
        .txe_flag_reg(txe_flag_i_2_n_0),
        .txe_flag_reg_0(\tx_s_tick_cnt[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \tx_bit_ptr[0]_i_1 
       (.I0(tx_state__0[1]),
        .I1(tx_bit_ptr[0]),
        .O(\tx_bit_ptr[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h28)) 
    \tx_bit_ptr[1]_i_1 
       (.I0(tx_state__0[1]),
        .I1(tx_bit_ptr[1]),
        .I2(tx_bit_ptr[0]),
        .O(\tx_bit_ptr[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h6A00)) 
    \tx_bit_ptr[2]_i_1 
       (.I0(tx_bit_ptr[2]),
        .I1(tx_bit_ptr[1]),
        .I2(tx_bit_ptr[0]),
        .I3(tx_state__0[1]),
        .O(\tx_bit_ptr[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h2AAA8000)) 
    \tx_bit_ptr[3]_i_2 
       (.I0(tx_state__0[1]),
        .I1(tx_bit_ptr[2]),
        .I2(tx_bit_ptr[1]),
        .I3(tx_bit_ptr[0]),
        .I4(tx_bit_ptr[3]),
        .O(\tx_bit_ptr[3]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \tx_bit_ptr[3]_i_4 
       (.I0(\tx_s_tick_cnt_reg_n_0_[2] ),
        .I1(\tx_s_tick_cnt_reg_n_0_[0] ),
        .I2(\tx_s_tick_cnt_reg_n_0_[1] ),
        .I3(\tx_s_tick_cnt_reg_n_0_[3] ),
        .O(\tx_bit_ptr[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h5455555555555515)) 
    \tx_bit_ptr[3]_i_5 
       (.I0(tx_state__0[0]),
        .I1(M),
        .I2(tx_bit_ptr[3]),
        .I3(tx_bit_ptr[0]),
        .I4(tx_bit_ptr[1]),
        .I5(tx_bit_ptr[2]),
        .O(\tx_bit_ptr[3]_i_5_n_0 ));
  FDCE \tx_bit_ptr_reg[0] 
       (.C(clk),
        .CE(baud_gen_inst_n_4),
        .CLR(rst),
        .D(\tx_bit_ptr[0]_i_1_n_0 ),
        .Q(tx_bit_ptr[0]));
  FDCE \tx_bit_ptr_reg[1] 
       (.C(clk),
        .CE(baud_gen_inst_n_4),
        .CLR(rst),
        .D(\tx_bit_ptr[1]_i_1_n_0 ),
        .Q(tx_bit_ptr[1]));
  FDCE \tx_bit_ptr_reg[2] 
       (.C(clk),
        .CE(baud_gen_inst_n_4),
        .CLR(rst),
        .D(\tx_bit_ptr[2]_i_1_n_0 ),
        .Q(tx_bit_ptr[2]));
  FDCE \tx_bit_ptr_reg[3] 
       (.C(clk),
        .CE(baud_gen_inst_n_4),
        .CLR(rst),
        .D(\tx_bit_ptr[3]_i_2_n_0 ),
        .Q(tx_bit_ptr[3]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    tx_i_2
       (.I0(\CR1_reg_reg_n_0_[0] ),
        .I1(\CR1_reg_reg_n_0_[1] ),
        .I2(tx_state__0[2]),
        .I3(tx_state__0[1]),
        .O(tx_i_2_n_0));
  LUT6 #(
    .INIT(64'hAAABAAABAAABAAAA)) 
    tx_i_3
       (.I0(tx_i_6_n_0),
        .I1(tx_i_7_n_0),
        .I2(tx_bit_ptr[3]),
        .I3(tx_state__0[0]),
        .I4(tx_bit_ptr[2]),
        .I5(tx_i_8_n_0),
        .O(tx_i_3_n_0));
  LUT6 #(
    .INIT(64'h7DD7D77DD77D7DD7)) 
    tx_i_4
       (.I0(tx_state__0[1]),
        .I1(tx_i_9_n_0),
        .I2(tx_shift_reg[3]),
        .I3(tx_shift_reg[2]),
        .I4(tx_shift_reg[1]),
        .I5(tx_shift_reg[0]),
        .O(tx_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h777F)) 
    tx_i_6
       (.I0(\CR1_reg_reg_n_0_[0] ),
        .I1(\CR1_reg_reg_n_0_[1] ),
        .I2(tx_state__0[0]),
        .I3(tx_state__0[1]),
        .O(tx_i_6_n_0));
  LUT6 #(
    .INIT(64'hA0A002A2AAAA02A2)) 
    tx_i_7
       (.I0(tx_bit_ptr[2]),
        .I1(tx_shift_reg[4]),
        .I2(tx_bit_ptr[0]),
        .I3(tx_shift_reg[5]),
        .I4(tx_bit_ptr[1]),
        .I5(tx_shift_reg[6]),
        .O(tx_i_7_n_0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    tx_i_8
       (.I0(tx_shift_reg[3]),
        .I1(tx_shift_reg[2]),
        .I2(tx_bit_ptr[1]),
        .I3(tx_shift_reg[1]),
        .I4(tx_bit_ptr[0]),
        .I5(tx_shift_reg[0]),
        .O(tx_i_8_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    tx_i_9
       (.I0(tx_shift_reg[6]),
        .I1(tx_shift_reg[5]),
        .I2(tx_shift_reg[4]),
        .I3(PS),
        .O(tx_i_9_n_0));
  FDPE tx_reg
       (.C(clk),
        .CE(1'b1),
        .D(baud_gen_inst_n_7),
        .PRE(rst),
        .Q(tx_out));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h0303033A)) 
    \tx_s_tick_cnt[0]_i_1 
       (.I0(sr_out_wire),
        .I1(\tx_s_tick_cnt_reg_n_0_[0] ),
        .I2(tx_state__0[2]),
        .I3(tx_state__0[0]),
        .I4(tx_state__0[1]),
        .O(\tx_s_tick_cnt[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h003C003C003C3CAA)) 
    \tx_s_tick_cnt[1]_i_1 
       (.I0(sr_out_wire),
        .I1(\tx_s_tick_cnt_reg_n_0_[0] ),
        .I2(\tx_s_tick_cnt_reg_n_0_[1] ),
        .I3(tx_state__0[2]),
        .I4(tx_state__0[0]),
        .I5(tx_state__0[1]),
        .O(\tx_s_tick_cnt[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00003CCC3CCCAAAA)) 
    \tx_s_tick_cnt[2]_i_1 
       (.I0(sr_out_wire),
        .I1(\tx_s_tick_cnt_reg_n_0_[2] ),
        .I2(\tx_s_tick_cnt_reg_n_0_[1] ),
        .I3(\tx_s_tick_cnt_reg_n_0_[0] ),
        .I4(tx_state__0[2]),
        .I5(\tx_s_tick_cnt[2]_i_2_n_0 ),
        .O(\tx_s_tick_cnt[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \tx_s_tick_cnt[2]_i_2 
       (.I0(tx_state__0[1]),
        .I1(tx_state__0[0]),
        .O(\tx_s_tick_cnt[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBEEEEEEEAAAAAAAA)) 
    \tx_s_tick_cnt[3]_i_2 
       (.I0(\tx_s_tick_cnt[3]_i_3_n_0 ),
        .I1(\tx_s_tick_cnt_reg_n_0_[3] ),
        .I2(\tx_s_tick_cnt_reg_n_0_[1] ),
        .I3(\tx_s_tick_cnt_reg_n_0_[0] ),
        .I4(\tx_s_tick_cnt_reg_n_0_[2] ),
        .I5(\tx_s_tick_cnt[3]_i_4_n_0 ),
        .O(\tx_s_tick_cnt[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0002)) 
    \tx_s_tick_cnt[3]_i_3 
       (.I0(sr_out_wire),
        .I1(tx_state__0[1]),
        .I2(tx_state__0[0]),
        .I3(tx_state__0[2]),
        .O(\tx_s_tick_cnt[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \tx_s_tick_cnt[3]_i_4 
       (.I0(tx_state__0[2]),
        .I1(tx_state__0[0]),
        .I2(tx_state__0[1]),
        .O(\tx_s_tick_cnt[3]_i_4_n_0 ));
  FDCE \tx_s_tick_cnt_reg[0] 
       (.C(clk),
        .CE(baud_gen_inst_n_3),
        .CLR(rst),
        .D(\tx_s_tick_cnt[0]_i_1_n_0 ),
        .Q(\tx_s_tick_cnt_reg_n_0_[0] ));
  FDCE \tx_s_tick_cnt_reg[1] 
       (.C(clk),
        .CE(baud_gen_inst_n_3),
        .CLR(rst),
        .D(\tx_s_tick_cnt[1]_i_1_n_0 ),
        .Q(\tx_s_tick_cnt_reg_n_0_[1] ));
  FDCE \tx_s_tick_cnt_reg[2] 
       (.C(clk),
        .CE(baud_gen_inst_n_3),
        .CLR(rst),
        .D(\tx_s_tick_cnt[2]_i_1_n_0 ),
        .Q(\tx_s_tick_cnt_reg_n_0_[2] ));
  FDCE \tx_s_tick_cnt_reg[3] 
       (.C(clk),
        .CE(baud_gen_inst_n_3),
        .CLR(rst),
        .D(\tx_s_tick_cnt[3]_i_2_n_0 ),
        .Q(\tx_s_tick_cnt_reg_n_0_[3] ));
  FDCE \tx_shift_reg_reg[0] 
       (.C(clk),
        .CE(baud_gen_inst_n_5),
        .CLR(rst),
        .D(TDR_reg[0]),
        .Q(tx_shift_reg[0]));
  FDCE \tx_shift_reg_reg[1] 
       (.C(clk),
        .CE(baud_gen_inst_n_5),
        .CLR(rst),
        .D(TDR_reg[1]),
        .Q(tx_shift_reg[1]));
  FDCE \tx_shift_reg_reg[2] 
       (.C(clk),
        .CE(baud_gen_inst_n_5),
        .CLR(rst),
        .D(TDR_reg[2]),
        .Q(tx_shift_reg[2]));
  FDCE \tx_shift_reg_reg[3] 
       (.C(clk),
        .CE(baud_gen_inst_n_5),
        .CLR(rst),
        .D(TDR_reg[3]),
        .Q(tx_shift_reg[3]));
  FDCE \tx_shift_reg_reg[4] 
       (.C(clk),
        .CE(baud_gen_inst_n_5),
        .CLR(rst),
        .D(TDR_reg[4]),
        .Q(tx_shift_reg[4]));
  FDCE \tx_shift_reg_reg[5] 
       (.C(clk),
        .CE(baud_gen_inst_n_5),
        .CLR(rst),
        .D(TDR_reg[5]),
        .Q(tx_shift_reg[5]));
  FDCE \tx_shift_reg_reg[6] 
       (.C(clk),
        .CE(baud_gen_inst_n_5),
        .CLR(rst),
        .D(TDR_reg[6]),
        .Q(tx_shift_reg[6]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0800)) 
    txe_flag_i_2
       (.I0(\TDR_reg[6]_i_2_n_0 ),
        .I1(Q[3]),
        .I2(Q[2]),
        .I3(Q[1]),
        .O(txe_flag_i_2_n_0));
  FDPE txe_flag_reg
       (.C(clk),
        .CE(1'b1),
        .D(baud_gen_inst_n_6),
        .PRE(rst),
        .Q(sr_out_wire));
endmodule

(* ORIG_REF_NAME = "apb_interface" *) 
module design1_hw_apb_uart_tb_0_0_apb_interface
   (penable_reg_0,
    \psel_reg[1]_0 ,
    E,
    state,
    \FSM_onehot_state_reg[6] ,
    \FSM_onehot_state_reg[1] ,
    tx_out,
    rst,
    clk,
    pwrite_reg_0,
    penable_reg_1,
    \delay_cnt_reg[0] ,
    Q,
    cpu_write_reg,
    \paddr_reg[6]_0 ,
    \pwdata_reg[6]_0 );
  output penable_reg_0;
  output \psel_reg[1]_0 ;
  output [0:0]E;
  output [1:0]state;
  output [0:0]\FSM_onehot_state_reg[6] ;
  output \FSM_onehot_state_reg[1] ;
  output tx_out;
  input rst;
  input clk;
  input pwrite_reg_0;
  input penable_reg_1;
  input \delay_cnt_reg[0] ;
  input [3:0]Q;
  input [0:0]cpu_write_reg;
  input [3:0]\paddr_reg[6]_0 ;
  input [6:0]\pwdata_reg[6]_0 ;

  wire [0:0]E;
  wire \FSM_onehot_state_reg[1] ;
  wire [0:0]\FSM_onehot_state_reg[6] ;
  wire \FSM_sequential_state[0]_i_1_n_0 ;
  wire \FSM_sequential_state[1]_i_1_n_0 ;
  wire \FSM_sequential_state[1]_i_2_n_0 ;
  wire [3:0]Q;
  wire apb_done;
  wire clk;
  wire cpu_write;
  wire [0:0]cpu_write_reg;
  wire \delay_cnt_reg[0] ;
  wire \paddr[6]_i_1_n_0 ;
  wire [3:0]\paddr_reg[6]_0 ;
  wire \paddr_reg_n_0_[2] ;
  wire \paddr_reg_n_0_[3] ;
  wire \paddr_reg_n_0_[4] ;
  wire \paddr_reg_n_0_[6] ;
  wire penable_reg_0;
  wire penable_reg_1;
  wire \psel[1]_i_1_n_0 ;
  wire \psel_reg[1]_0 ;
  wire [6:0]\pwdata_reg[6]_0 ;
  wire \pwdata_reg_n_0_[0] ;
  wire \pwdata_reg_n_0_[1] ;
  wire \pwdata_reg_n_0_[2] ;
  wire \pwdata_reg_n_0_[3] ;
  wire \pwdata_reg_n_0_[4] ;
  wire \pwdata_reg_n_0_[5] ;
  wire \pwdata_reg_n_0_[6] ;
  wire pwrite_reg_0;
  wire pwrite_reg_n_0;
  wire rst;
  wire [1:0]state;
  wire tx_out;
  wire txn_done_r;

  LUT3 #(
    .INIT(8'hEA)) 
    \FSM_onehot_state[7]_inv_i_1 
       (.I0(cpu_write),
        .I1(Q[3]),
        .I2(\delay_cnt_reg[0] ),
        .O(\FSM_onehot_state_reg[6] ));
  LUT6 #(
    .INIT(64'hFFFEAAAAAAAAAAAA)) 
    \FSM_onehot_state[7]_inv_i_3 
       (.I0(cpu_write_reg),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[1]),
        .I4(state[0]),
        .I5(state[1]),
        .O(cpu_write));
  LUT6 #(
    .INIT(64'h3333CCEC33330020)) 
    \FSM_sequential_state[0]_i_1 
       (.I0(pwrite_reg_0),
        .I1(state[1]),
        .I2(\paddr_reg[6]_0 [3]),
        .I3(txn_done_r),
        .I4(state[0]),
        .I5(\FSM_sequential_state[1]_i_2_n_0 ),
        .O(\FSM_sequential_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h3333CCDC0000CCDC)) 
    \FSM_sequential_state[1]_i_1 
       (.I0(pwrite_reg_0),
        .I1(state[1]),
        .I2(\paddr_reg[6]_0 [3]),
        .I3(txn_done_r),
        .I4(state[0]),
        .I5(\FSM_sequential_state[1]_i_2_n_0 ),
        .O(\FSM_sequential_state[1]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \FSM_sequential_state[1]_i_2 
       (.I0(penable_reg_0),
        .I1(\psel_reg[1]_0 ),
        .O(\FSM_sequential_state[1]_i_2_n_0 ));
  (* FSM_ENCODED_STATES = "READ:10,WRITE:01,IDLE:00,WAIT:11" *) 
  FDRE \FSM_sequential_state_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_sequential_state[0]_i_1_n_0 ),
        .Q(state[0]),
        .R(rst));
  (* FSM_ENCODED_STATES = "READ:10,WRITE:01,IDLE:00,WAIT:11" *) 
  FDRE \FSM_sequential_state_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_sequential_state[1]_i_1_n_0 ),
        .Q(state[1]),
        .R(rst));
  LUT6 #(
    .INIT(64'hAAABFFFFAAAAAAAA)) 
    cpu_write_i_1
       (.I0(cpu_write_reg),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[1]),
        .I4(apb_done),
        .I5(pwrite_reg_0),
        .O(\FSM_onehot_state_reg[1] ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hF4444444)) 
    \delay_cnt[15]_i_1 
       (.I0(\delay_cnt_reg[0] ),
        .I1(Q[3]),
        .I2(Q[2]),
        .I3(state[0]),
        .I4(state[1]),
        .O(E));
  LUT4 #(
    .INIT(16'h0004)) 
    \paddr[6]_i_1 
       (.I0(txn_done_r),
        .I1(\paddr_reg[6]_0 [3]),
        .I2(state[0]),
        .I3(state[1]),
        .O(\paddr[6]_i_1_n_0 ));
  FDRE \paddr_reg[2] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\paddr_reg[6]_0 [0]),
        .Q(\paddr_reg_n_0_[2] ),
        .R(rst));
  FDRE \paddr_reg[3] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\paddr_reg[6]_0 [1]),
        .Q(\paddr_reg_n_0_[3] ),
        .R(rst));
  FDRE \paddr_reg[4] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\paddr_reg[6]_0 [2]),
        .Q(\paddr_reg_n_0_[4] ),
        .R(rst));
  FDRE \paddr_reg[6] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\paddr_reg[6]_0 [3]),
        .Q(\paddr_reg_n_0_[6] ),
        .R(rst));
  FDRE penable_reg
       (.C(clk),
        .CE(1'b1),
        .D(penable_reg_1),
        .Q(penable_reg_0),
        .R(rst));
  LUT6 #(
    .INIT(64'hF000FF000202F202)) 
    \psel[1]_i_1 
       (.I0(\paddr_reg[6]_0 [3]),
        .I1(txn_done_r),
        .I2(state[1]),
        .I3(\psel_reg[1]_0 ),
        .I4(penable_reg_0),
        .I5(state[0]),
        .O(\psel[1]_i_1_n_0 ));
  FDRE \psel_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\psel[1]_i_1_n_0 ),
        .Q(\psel_reg[1]_0 ),
        .R(rst));
  FDRE \pwdata_reg[0] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\pwdata_reg[6]_0 [0]),
        .Q(\pwdata_reg_n_0_[0] ),
        .R(rst));
  FDRE \pwdata_reg[1] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\pwdata_reg[6]_0 [1]),
        .Q(\pwdata_reg_n_0_[1] ),
        .R(rst));
  FDRE \pwdata_reg[2] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\pwdata_reg[6]_0 [2]),
        .Q(\pwdata_reg_n_0_[2] ),
        .R(rst));
  FDRE \pwdata_reg[3] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\pwdata_reg[6]_0 [3]),
        .Q(\pwdata_reg_n_0_[3] ),
        .R(rst));
  FDRE \pwdata_reg[4] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\pwdata_reg[6]_0 [4]),
        .Q(\pwdata_reg_n_0_[4] ),
        .R(rst));
  FDRE \pwdata_reg[5] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\pwdata_reg[6]_0 [5]),
        .Q(\pwdata_reg_n_0_[5] ),
        .R(rst));
  FDRE \pwdata_reg[6] 
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(\pwdata_reg[6]_0 [6]),
        .Q(\pwdata_reg_n_0_[6] ),
        .R(rst));
  FDRE pwrite_reg
       (.C(clk),
        .CE(\paddr[6]_i_1_n_0 ),
        .D(pwrite_reg_0),
        .Q(pwrite_reg_n_0),
        .R(rst));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h8)) 
    txn_done_r_i_1
       (.I0(state[0]),
        .I1(state[1]),
        .O(apb_done));
  FDRE txn_done_r_reg
       (.C(clk),
        .CE(1'b1),
        .D(apb_done),
        .Q(txn_done_r),
        .R(rst));
  design1_hw_apb_uart_tb_0_0_uart_top uart_u
       (.\CR1_reg_reg[0] (penable_reg_0),
        .\CR1_reg_reg[0]_0 (\psel_reg[1]_0 ),
        .\CR1_reg_reg[0]_1 (pwrite_reg_n_0),
        .Q({\paddr_reg_n_0_[6] ,\paddr_reg_n_0_[4] ,\paddr_reg_n_0_[3] ,\paddr_reg_n_0_[2] }),
        .\TDR_reg_reg[6] ({\pwdata_reg_n_0_[6] ,\pwdata_reg_n_0_[5] ,\pwdata_reg_n_0_[4] ,\pwdata_reg_n_0_[3] ,\pwdata_reg_n_0_[2] ,\pwdata_reg_n_0_[1] ,\pwdata_reg_n_0_[0] }),
        .clk(clk),
        .rst(rst),
        .tx_out(tx_out));
endmodule

(* ORIG_REF_NAME = "baud_rate_gen" *) 
module design1_hw_apb_uart_tb_0_0_baud_rate_gen
   (baud_tick_reg_0,
    \CR1_reg_reg[4] ,
    \FSM_sequential_tx_state_reg[2] ,
    E,
    \FSM_sequential_tx_state_reg[1] ,
    \FSM_sequential_tx_state_reg[2]_0 ,
    \FSM_sequential_tx_state_reg[2]_1 ,
    \FSM_sequential_tx_state_reg[0] ,
    clk,
    rst,
    Q,
    tx_state__0,
    \FSM_sequential_tx_state_reg[2]_2 ,
    \FSM_sequential_tx_state_reg[2]_3 ,
    \FSM_sequential_tx_state_reg[1]_0 ,
    \FSM_sequential_tx_state_reg[0]_0 ,
    sr_out_wire,
    \tx_bit_ptr_reg[0] ,
    \tx_bit_ptr_reg[0]_0 ,
    txe_flag_reg,
    txe_flag_reg_0,
    tx_reg,
    tx_reg_0,
    tx_reg_1,
    tx_out,
    baud_tick_reg_1);
  output baud_tick_reg_0;
  output \CR1_reg_reg[4] ;
  output \FSM_sequential_tx_state_reg[2] ;
  output [0:0]E;
  output [0:0]\FSM_sequential_tx_state_reg[1] ;
  output [0:0]\FSM_sequential_tx_state_reg[2]_0 ;
  output \FSM_sequential_tx_state_reg[2]_1 ;
  output \FSM_sequential_tx_state_reg[0] ;
  input clk;
  input rst;
  input [2:0]Q;
  input [2:0]tx_state__0;
  input \FSM_sequential_tx_state_reg[2]_2 ;
  input \FSM_sequential_tx_state_reg[2]_3 ;
  input \FSM_sequential_tx_state_reg[1]_0 ;
  input \FSM_sequential_tx_state_reg[0]_0 ;
  input [0:0]sr_out_wire;
  input \tx_bit_ptr_reg[0] ;
  input \tx_bit_ptr_reg[0]_0 ;
  input txe_flag_reg;
  input txe_flag_reg_0;
  input tx_reg;
  input tx_reg_0;
  input tx_reg_1;
  input tx_out;
  input [6:0]baud_tick_reg_1;

  wire \CR1_reg_reg[4] ;
  wire [0:0]E;
  wire \FSM_sequential_tx_state_reg[0] ;
  wire \FSM_sequential_tx_state_reg[0]_0 ;
  wire [0:0]\FSM_sequential_tx_state_reg[1] ;
  wire \FSM_sequential_tx_state_reg[1]_0 ;
  wire \FSM_sequential_tx_state_reg[2] ;
  wire [0:0]\FSM_sequential_tx_state_reg[2]_0 ;
  wire \FSM_sequential_tx_state_reg[2]_1 ;
  wire \FSM_sequential_tx_state_reg[2]_2 ;
  wire \FSM_sequential_tx_state_reg[2]_3 ;
  wire [2:0]Q;
  wire baud_tick_16x;
  wire baud_tick_i_2_n_0;
  wire baud_tick_reg_0;
  wire [6:0]baud_tick_reg_1;
  wire clk;
  wire counter1_carry__0_i_1_n_0;
  wire counter1_carry__0_i_2_n_0;
  wire counter1_carry__0_n_0;
  wire counter1_carry__0_n_1;
  wire counter1_carry__0_n_2;
  wire counter1_carry__0_n_3;
  wire counter1_carry__1_n_2;
  wire counter1_carry__1_n_3;
  wire counter1_carry_i_1_n_0;
  wire counter1_carry_i_2_n_0;
  wire counter1_carry_i_3_n_0;
  wire counter1_carry_i_4_n_0;
  wire counter1_carry_n_0;
  wire counter1_carry_n_1;
  wire counter1_carry_n_2;
  wire counter1_carry_n_3;
  wire [6:1]counter2;
  wire counter2_carry__0_i_1_n_0;
  wire counter2_carry__0_i_2_n_0;
  wire counter2_carry__0_n_1;
  wire counter2_carry__0_n_3;
  wire counter2_carry_i_1_n_0;
  wire counter2_carry_i_2_n_0;
  wire counter2_carry_i_3_n_0;
  wire counter2_carry_i_4_n_0;
  wire counter2_carry_n_0;
  wire counter2_carry_n_1;
  wire counter2_carry_n_2;
  wire counter2_carry_n_3;
  wire \counter[0]_i_2_n_0 ;
  wire \counter[0]_i_3_n_0 ;
  wire \counter[0]_i_4_n_0 ;
  wire \counter[0]_i_5_n_0 ;
  wire \counter[0]_i_6_n_0 ;
  wire \counter[12]_i_2_n_0 ;
  wire \counter[12]_i_3_n_0 ;
  wire \counter[12]_i_4_n_0 ;
  wire \counter[12]_i_5_n_0 ;
  wire \counter[4]_i_2_n_0 ;
  wire \counter[4]_i_3_n_0 ;
  wire \counter[4]_i_4_n_0 ;
  wire \counter[4]_i_5_n_0 ;
  wire \counter[8]_i_2_n_0 ;
  wire \counter[8]_i_3_n_0 ;
  wire \counter[8]_i_4_n_0 ;
  wire \counter[8]_i_5_n_0 ;
  wire [15:0]counter_reg;
  wire \counter_reg[0]_i_1_n_0 ;
  wire \counter_reg[0]_i_1_n_1 ;
  wire \counter_reg[0]_i_1_n_2 ;
  wire \counter_reg[0]_i_1_n_3 ;
  wire \counter_reg[0]_i_1_n_4 ;
  wire \counter_reg[0]_i_1_n_5 ;
  wire \counter_reg[0]_i_1_n_6 ;
  wire \counter_reg[0]_i_1_n_7 ;
  wire \counter_reg[12]_i_1_n_1 ;
  wire \counter_reg[12]_i_1_n_2 ;
  wire \counter_reg[12]_i_1_n_3 ;
  wire \counter_reg[12]_i_1_n_4 ;
  wire \counter_reg[12]_i_1_n_5 ;
  wire \counter_reg[12]_i_1_n_6 ;
  wire \counter_reg[12]_i_1_n_7 ;
  wire \counter_reg[4]_i_1_n_0 ;
  wire \counter_reg[4]_i_1_n_1 ;
  wire \counter_reg[4]_i_1_n_2 ;
  wire \counter_reg[4]_i_1_n_3 ;
  wire \counter_reg[4]_i_1_n_4 ;
  wire \counter_reg[4]_i_1_n_5 ;
  wire \counter_reg[4]_i_1_n_6 ;
  wire \counter_reg[4]_i_1_n_7 ;
  wire \counter_reg[8]_i_1_n_0 ;
  wire \counter_reg[8]_i_1_n_1 ;
  wire \counter_reg[8]_i_1_n_2 ;
  wire \counter_reg[8]_i_1_n_3 ;
  wire \counter_reg[8]_i_1_n_4 ;
  wire \counter_reg[8]_i_1_n_5 ;
  wire \counter_reg[8]_i_1_n_6 ;
  wire \counter_reg[8]_i_1_n_7 ;
  wire load;
  wire rst;
  wire sel;
  wire [0:0]sr_out_wire;
  wire \tx_bit_ptr[3]_i_3_n_0 ;
  wire \tx_bit_ptr_reg[0] ;
  wire \tx_bit_ptr_reg[0]_0 ;
  wire tx_i_5_n_0;
  wire tx_out;
  wire tx_reg;
  wire tx_reg_0;
  wire tx_reg_1;
  wire [2:0]tx_state__0;
  wire txe_flag_reg;
  wire txe_flag_reg_0;
  wire [3:0]NLW_counter1_carry_O_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__0_O_UNCONNECTED;
  wire [3:3]NLW_counter1_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_counter1_carry__1_O_UNCONNECTED;
  wire [3:1]NLW_counter2_carry__0_CO_UNCONNECTED;
  wire [3:2]NLW_counter2_carry__0_O_UNCONNECTED;
  wire [3:3]\NLW_counter_reg[12]_i_1_CO_UNCONNECTED ;

  LUT6 #(
    .INIT(64'hF0FF000001000000)) 
    \FSM_sequential_tx_state[0]_i_1 
       (.I0(tx_state__0[2]),
        .I1(\FSM_sequential_tx_state_reg[0]_0 ),
        .I2(\FSM_sequential_tx_state_reg[2]_3 ),
        .I3(baud_tick_16x),
        .I4(\FSM_sequential_tx_state_reg[1]_0 ),
        .I5(tx_state__0[0]),
        .O(\FSM_sequential_tx_state_reg[2] ));
  LUT6 #(
    .INIT(64'hF2FF00000C000000)) 
    \FSM_sequential_tx_state[1]_i_1 
       (.I0(Q[2]),
        .I1(tx_state__0[0]),
        .I2(\FSM_sequential_tx_state_reg[2]_3 ),
        .I3(baud_tick_16x),
        .I4(\FSM_sequential_tx_state_reg[1]_0 ),
        .I5(tx_state__0[1]),
        .O(\CR1_reg_reg[4] ));
  LUT6 #(
    .INIT(64'hDF00000010000000)) 
    \FSM_sequential_tx_state[2]_i_1 
       (.I0(\FSM_sequential_tx_state_reg[2]_2 ),
        .I1(\FSM_sequential_tx_state_reg[2]_3 ),
        .I2(baud_tick_16x),
        .I3(Q[0]),
        .I4(Q[1]),
        .I5(tx_state__0[2]),
        .O(baud_tick_reg_0));
  LUT2 #(
    .INIT(4'hE)) 
    baud_tick_i_1
       (.I0(baud_tick_i_2_n_0),
        .I1(baud_tick_reg_1[0]),
        .O(sel));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    baud_tick_i_2
       (.I0(baud_tick_reg_1[3]),
        .I1(baud_tick_reg_1[4]),
        .I2(baud_tick_reg_1[1]),
        .I3(baud_tick_reg_1[2]),
        .I4(baud_tick_reg_1[6]),
        .I5(baud_tick_reg_1[5]),
        .O(baud_tick_i_2_n_0));
  FDCE baud_tick_reg
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(load),
        .Q(baud_tick_16x));
  CARRY4 counter1_carry
       (.CI(1'b0),
        .CO({counter1_carry_n_0,counter1_carry_n_1,counter1_carry_n_2,counter1_carry_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_counter1_carry_O_UNCONNECTED[3:0]),
        .S({counter1_carry_i_1_n_0,counter1_carry_i_2_n_0,counter1_carry_i_3_n_0,counter1_carry_i_4_n_0}));
  CARRY4 counter1_carry__0
       (.CI(counter1_carry_n_0),
        .CO({counter1_carry__0_n_0,counter1_carry__0_n_1,counter1_carry__0_n_2,counter1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_counter1_carry__0_O_UNCONNECTED[3:0]),
        .S({counter2_carry__0_n_1,counter2_carry__0_n_1,counter1_carry__0_i_1_n_0,counter1_carry__0_i_2_n_0}));
  LUT2 #(
    .INIT(4'h4)) 
    counter1_carry__0_i_1
       (.I0(counter_reg[15]),
        .I1(counter2_carry__0_n_1),
        .O(counter1_carry__0_i_1_n_0));
  LUT4 #(
    .INIT(16'h2004)) 
    counter1_carry__0_i_2
       (.I0(counter_reg[12]),
        .I1(counter2_carry__0_n_1),
        .I2(counter_reg[14]),
        .I3(counter_reg[13]),
        .O(counter1_carry__0_i_2_n_0));
  CARRY4 counter1_carry__1
       (.CI(counter1_carry__0_n_0),
        .CO({NLW_counter1_carry__1_CO_UNCONNECTED[3],load,counter1_carry__1_n_2,counter1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_counter1_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,counter2_carry__0_n_1,counter2_carry__0_n_1,counter2_carry__0_n_1}));
  LUT4 #(
    .INIT(16'h2004)) 
    counter1_carry_i_1
       (.I0(counter_reg[9]),
        .I1(counter2_carry__0_n_1),
        .I2(counter_reg[11]),
        .I3(counter_reg[10]),
        .O(counter1_carry_i_1_n_0));
  LUT5 #(
    .INIT(32'h09000090)) 
    counter1_carry_i_2
       (.I0(counter_reg[6]),
        .I1(counter2[6]),
        .I2(counter2_carry__0_n_1),
        .I3(counter_reg[8]),
        .I4(counter_reg[7]),
        .O(counter1_carry_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    counter1_carry_i_3
       (.I0(counter_reg[3]),
        .I1(counter2[3]),
        .I2(counter2[5]),
        .I3(counter_reg[5]),
        .I4(counter2[4]),
        .I5(counter_reg[4]),
        .O(counter1_carry_i_3_n_0));
  LUT6 #(
    .INIT(64'h6006000000006006)) 
    counter1_carry_i_4
       (.I0(counter_reg[0]),
        .I1(baud_tick_reg_1[0]),
        .I2(counter2[2]),
        .I3(counter_reg[2]),
        .I4(counter2[1]),
        .I5(counter_reg[1]),
        .O(counter1_carry_i_4_n_0));
  CARRY4 counter2_carry
       (.CI(1'b0),
        .CO({counter2_carry_n_0,counter2_carry_n_1,counter2_carry_n_2,counter2_carry_n_3}),
        .CYINIT(baud_tick_reg_1[0]),
        .DI(baud_tick_reg_1[4:1]),
        .O(counter2[4:1]),
        .S({counter2_carry_i_1_n_0,counter2_carry_i_2_n_0,counter2_carry_i_3_n_0,counter2_carry_i_4_n_0}));
  CARRY4 counter2_carry__0
       (.CI(counter2_carry_n_0),
        .CO({NLW_counter2_carry__0_CO_UNCONNECTED[3],counter2_carry__0_n_1,NLW_counter2_carry__0_CO_UNCONNECTED[1],counter2_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,baud_tick_reg_1[6:5]}),
        .O({NLW_counter2_carry__0_O_UNCONNECTED[3:2],counter2[6:5]}),
        .S({1'b0,1'b1,counter2_carry__0_i_1_n_0,counter2_carry__0_i_2_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    counter2_carry__0_i_1
       (.I0(baud_tick_reg_1[6]),
        .O(counter2_carry__0_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter2_carry__0_i_2
       (.I0(baud_tick_reg_1[5]),
        .O(counter2_carry__0_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter2_carry_i_1
       (.I0(baud_tick_reg_1[4]),
        .O(counter2_carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter2_carry_i_2
       (.I0(baud_tick_reg_1[3]),
        .O(counter2_carry_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter2_carry_i_3
       (.I0(baud_tick_reg_1[2]),
        .O(counter2_carry_i_3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    counter2_carry_i_4
       (.I0(baud_tick_reg_1[1]),
        .O(counter2_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[0]_i_2 
       (.I0(counter_reg[0]),
        .I1(load),
        .O(\counter[0]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[0]_i_3 
       (.I0(counter_reg[3]),
        .I1(load),
        .O(\counter[0]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[0]_i_4 
       (.I0(counter_reg[2]),
        .I1(load),
        .O(\counter[0]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[0]_i_5 
       (.I0(counter_reg[1]),
        .I1(load),
        .O(\counter[0]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \counter[0]_i_6 
       (.I0(counter_reg[0]),
        .I1(load),
        .O(\counter[0]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[12]_i_2 
       (.I0(counter_reg[15]),
        .I1(load),
        .O(\counter[12]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[12]_i_3 
       (.I0(counter_reg[14]),
        .I1(load),
        .O(\counter[12]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[12]_i_4 
       (.I0(counter_reg[13]),
        .I1(load),
        .O(\counter[12]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[12]_i_5 
       (.I0(counter_reg[12]),
        .I1(load),
        .O(\counter[12]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[4]_i_2 
       (.I0(counter_reg[7]),
        .I1(load),
        .O(\counter[4]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[4]_i_3 
       (.I0(counter_reg[6]),
        .I1(load),
        .O(\counter[4]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[4]_i_4 
       (.I0(counter_reg[5]),
        .I1(load),
        .O(\counter[4]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[4]_i_5 
       (.I0(counter_reg[4]),
        .I1(load),
        .O(\counter[4]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[8]_i_2 
       (.I0(counter_reg[11]),
        .I1(load),
        .O(\counter[8]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[8]_i_3 
       (.I0(counter_reg[10]),
        .I1(load),
        .O(\counter[8]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[8]_i_4 
       (.I0(counter_reg[9]),
        .I1(load),
        .O(\counter[8]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \counter[8]_i_5 
       (.I0(counter_reg[8]),
        .I1(load),
        .O(\counter[8]_i_5_n_0 ));
  FDCE \counter_reg[0] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[0]_i_1_n_7 ),
        .Q(counter_reg[0]));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \counter_reg[0]_i_1 
       (.CI(1'b0),
        .CO({\counter_reg[0]_i_1_n_0 ,\counter_reg[0]_i_1_n_1 ,\counter_reg[0]_i_1_n_2 ,\counter_reg[0]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\counter[0]_i_2_n_0 }),
        .O({\counter_reg[0]_i_1_n_4 ,\counter_reg[0]_i_1_n_5 ,\counter_reg[0]_i_1_n_6 ,\counter_reg[0]_i_1_n_7 }),
        .S({\counter[0]_i_3_n_0 ,\counter[0]_i_4_n_0 ,\counter[0]_i_5_n_0 ,\counter[0]_i_6_n_0 }));
  FDCE \counter_reg[10] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[8]_i_1_n_5 ),
        .Q(counter_reg[10]));
  FDCE \counter_reg[11] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[8]_i_1_n_4 ),
        .Q(counter_reg[11]));
  FDCE \counter_reg[12] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[12]_i_1_n_7 ),
        .Q(counter_reg[12]));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \counter_reg[12]_i_1 
       (.CI(\counter_reg[8]_i_1_n_0 ),
        .CO({\NLW_counter_reg[12]_i_1_CO_UNCONNECTED [3],\counter_reg[12]_i_1_n_1 ,\counter_reg[12]_i_1_n_2 ,\counter_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[12]_i_1_n_4 ,\counter_reg[12]_i_1_n_5 ,\counter_reg[12]_i_1_n_6 ,\counter_reg[12]_i_1_n_7 }),
        .S({\counter[12]_i_2_n_0 ,\counter[12]_i_3_n_0 ,\counter[12]_i_4_n_0 ,\counter[12]_i_5_n_0 }));
  FDCE \counter_reg[13] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[12]_i_1_n_6 ),
        .Q(counter_reg[13]));
  FDCE \counter_reg[14] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[12]_i_1_n_5 ),
        .Q(counter_reg[14]));
  FDCE \counter_reg[15] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[12]_i_1_n_4 ),
        .Q(counter_reg[15]));
  FDCE \counter_reg[1] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[0]_i_1_n_6 ),
        .Q(counter_reg[1]));
  FDCE \counter_reg[2] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[0]_i_1_n_5 ),
        .Q(counter_reg[2]));
  FDCE \counter_reg[3] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[0]_i_1_n_4 ),
        .Q(counter_reg[3]));
  FDCE \counter_reg[4] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[4]_i_1_n_7 ),
        .Q(counter_reg[4]));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \counter_reg[4]_i_1 
       (.CI(\counter_reg[0]_i_1_n_0 ),
        .CO({\counter_reg[4]_i_1_n_0 ,\counter_reg[4]_i_1_n_1 ,\counter_reg[4]_i_1_n_2 ,\counter_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[4]_i_1_n_4 ,\counter_reg[4]_i_1_n_5 ,\counter_reg[4]_i_1_n_6 ,\counter_reg[4]_i_1_n_7 }),
        .S({\counter[4]_i_2_n_0 ,\counter[4]_i_3_n_0 ,\counter[4]_i_4_n_0 ,\counter[4]_i_5_n_0 }));
  FDCE \counter_reg[5] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[4]_i_1_n_6 ),
        .Q(counter_reg[5]));
  FDCE \counter_reg[6] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[4]_i_1_n_5 ),
        .Q(counter_reg[6]));
  FDCE \counter_reg[7] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[4]_i_1_n_4 ),
        .Q(counter_reg[7]));
  FDCE \counter_reg[8] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[8]_i_1_n_7 ),
        .Q(counter_reg[8]));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \counter_reg[8]_i_1 
       (.CI(\counter_reg[4]_i_1_n_0 ),
        .CO({\counter_reg[8]_i_1_n_0 ,\counter_reg[8]_i_1_n_1 ,\counter_reg[8]_i_1_n_2 ,\counter_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\counter_reg[8]_i_1_n_4 ,\counter_reg[8]_i_1_n_5 ,\counter_reg[8]_i_1_n_6 ,\counter_reg[8]_i_1_n_7 }),
        .S({\counter[8]_i_2_n_0 ,\counter[8]_i_3_n_0 ,\counter[8]_i_4_n_0 ,\counter[8]_i_5_n_0 }));
  FDCE \counter_reg[9] 
       (.C(clk),
        .CE(sel),
        .CLR(rst),
        .D(\counter_reg[8]_i_1_n_6 ),
        .Q(counter_reg[9]));
  LUT6 #(
    .INIT(64'h0000222000000200)) 
    \tx_bit_ptr[3]_i_1 
       (.I0(\tx_bit_ptr[3]_i_3_n_0 ),
        .I1(\tx_bit_ptr_reg[0] ),
        .I2(tx_state__0[1]),
        .I3(tx_state__0[0]),
        .I4(tx_state__0[2]),
        .I5(\tx_bit_ptr_reg[0]_0 ),
        .O(\FSM_sequential_tx_state_reg[1] ));
  LUT3 #(
    .INIT(8'h80)) 
    \tx_bit_ptr[3]_i_3 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(baud_tick_16x),
        .O(\tx_bit_ptr[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8A88FFFF8A880000)) 
    tx_i_1
       (.I0(tx_reg),
        .I1(tx_reg_0),
        .I2(tx_reg_1),
        .I3(tx_state__0[0]),
        .I4(tx_i_5_n_0),
        .I5(tx_out),
        .O(\FSM_sequential_tx_state_reg[0] ));
  LUT6 #(
    .INIT(64'h1F00FFFFFFFFFFFF)) 
    tx_i_5
       (.I0(tx_state__0[0]),
        .I1(tx_state__0[1]),
        .I2(tx_state__0[2]),
        .I3(baud_tick_16x),
        .I4(Q[0]),
        .I5(Q[1]),
        .O(tx_i_5_n_0));
  LUT6 #(
    .INIT(64'h0808088008080888)) 
    \tx_s_tick_cnt[3]_i_1 
       (.I0(\FSM_sequential_tx_state_reg[1]_0 ),
        .I1(baud_tick_16x),
        .I2(tx_state__0[2]),
        .I3(tx_state__0[0]),
        .I4(tx_state__0[1]),
        .I5(sr_out_wire),
        .O(E));
  LUT6 #(
    .INIT(64'h0001000000000000)) 
    \tx_shift_reg[6]_i_1 
       (.I0(tx_state__0[2]),
        .I1(tx_state__0[0]),
        .I2(tx_state__0[1]),
        .I3(sr_out_wire),
        .I4(baud_tick_16x),
        .I5(\FSM_sequential_tx_state_reg[1]_0 ),
        .O(\FSM_sequential_tx_state_reg[2]_0 ));
  LUT6 #(
    .INIT(64'h7777333777773333)) 
    txe_flag_i_1
       (.I0(txe_flag_reg),
        .I1(\FSM_sequential_tx_state_reg[1]_0 ),
        .I2(tx_state__0[2]),
        .I3(txe_flag_reg_0),
        .I4(sr_out_wire),
        .I5(baud_tick_16x),
        .O(\FSM_sequential_tx_state_reg[2]_1 ));
endmodule

(* ORIG_REF_NAME = "hw_apb_uart_tb" *) 
module design1_hw_apb_uart_tb_0_0_hw_apb_uart_tb
   (tx_out,
    tx_busy_led,
    clk,
    rst);
  output tx_out;
  output tx_busy_led;
  input clk;
  input rst;

  wire \FSM_onehot_state[4]_i_1_n_0 ;
  wire \FSM_onehot_state[4]_i_2_n_0 ;
  wire \FSM_onehot_state[7]_inv_i_2_n_0 ;
  wire \FSM_onehot_state[7]_inv_i_4_n_0 ;
  wire \FSM_onehot_state[7]_inv_i_5_n_0 ;
  wire \FSM_onehot_state[7]_inv_i_6_n_0 ;
  wire \FSM_onehot_state[7]_inv_i_7_n_0 ;
  wire \FSM_onehot_state[7]_inv_i_8_n_0 ;
  wire \FSM_onehot_state[7]_inv_i_9_n_0 ;
  wire \FSM_onehot_state_reg_n_0_[0] ;
  wire \FSM_onehot_state_reg_n_0_[1] ;
  wire \FSM_onehot_state_reg_n_0_[2] ;
  wire \FSM_onehot_state_reg_n_0_[3] ;
  wire \FSM_onehot_state_reg_n_0_[4] ;
  wire \FSM_onehot_state_reg_n_0_[5] ;
  wire \FSM_onehot_state_reg_n_0_[6] ;
  wire char_idx;
  wire \char_idx[0]_i_1_n_0 ;
  wire \char_idx[3]_i_1_n_0 ;
  wire [5:0]char_idx_reg;
  wire clk;
  wire [13:3]cpu_paddr;
  wire \cpu_paddr_reg_n_0_[13] ;
  wire \cpu_paddr_reg_n_0_[2] ;
  wire \cpu_paddr_reg_n_0_[3] ;
  wire \cpu_paddr_reg_n_0_[4] ;
  wire \cpu_wdata[0]_i_1_n_0 ;
  wire \cpu_wdata[1]_i_1_n_0 ;
  wire \cpu_wdata[1]_i_2_n_0 ;
  wire \cpu_wdata[2]_i_1_n_0 ;
  wire \cpu_wdata[3]_i_1_n_0 ;
  wire \cpu_wdata[3]_i_2_n_0 ;
  wire \cpu_wdata[4]_i_1_n_0 ;
  wire \cpu_wdata[4]_i_2_n_0 ;
  wire \cpu_wdata[5]_i_1_n_0 ;
  wire \cpu_wdata[6]_i_1_n_0 ;
  wire \cpu_wdata[6]_i_2_n_0 ;
  wire \cpu_wdata[6]_i_3_n_0 ;
  wire \cpu_wdata_reg_n_0_[0] ;
  wire \cpu_wdata_reg_n_0_[1] ;
  wire \cpu_wdata_reg_n_0_[2] ;
  wire \cpu_wdata_reg_n_0_[3] ;
  wire \cpu_wdata_reg_n_0_[4] ;
  wire \cpu_wdata_reg_n_0_[5] ;
  wire \cpu_wdata_reg_n_0_[6] ;
  wire cpu_write_reg_n_0;
  wire [15:0]delay_cnt;
  wire delay_cnt0_carry__0_i_1_n_0;
  wire delay_cnt0_carry__0_i_2_n_0;
  wire delay_cnt0_carry__0_i_3_n_0;
  wire delay_cnt0_carry__0_i_4_n_0;
  wire delay_cnt0_carry__0_n_0;
  wire delay_cnt0_carry__0_n_1;
  wire delay_cnt0_carry__0_n_2;
  wire delay_cnt0_carry__0_n_3;
  wire delay_cnt0_carry__1_i_1_n_0;
  wire delay_cnt0_carry__1_i_2_n_0;
  wire delay_cnt0_carry__1_i_3_n_0;
  wire delay_cnt0_carry__1_i_4_n_0;
  wire delay_cnt0_carry__1_n_0;
  wire delay_cnt0_carry__1_n_1;
  wire delay_cnt0_carry__1_n_2;
  wire delay_cnt0_carry__1_n_3;
  wire delay_cnt0_carry__2_i_1_n_0;
  wire delay_cnt0_carry__2_i_2_n_0;
  wire delay_cnt0_carry__2_i_3_n_0;
  wire delay_cnt0_carry__2_n_2;
  wire delay_cnt0_carry__2_n_3;
  wire delay_cnt0_carry_i_1_n_0;
  wire delay_cnt0_carry_i_2_n_0;
  wire delay_cnt0_carry_i_3_n_0;
  wire delay_cnt0_carry_i_4_n_0;
  wire delay_cnt0_carry_n_0;
  wire delay_cnt0_carry_n_1;
  wire delay_cnt0_carry_n_2;
  wire delay_cnt0_carry_n_3;
  wire \delay_cnt[0]_i_1_n_0 ;
  wire \delay_cnt[10]_i_1_n_0 ;
  wire \delay_cnt[11]_i_1_n_0 ;
  wire \delay_cnt[12]_i_1_n_0 ;
  wire \delay_cnt[13]_i_1_n_0 ;
  wire \delay_cnt[14]_i_1_n_0 ;
  wire \delay_cnt[15]_i_2_n_0 ;
  wire \delay_cnt[1]_i_1_n_0 ;
  wire \delay_cnt[2]_i_1_n_0 ;
  wire \delay_cnt[3]_i_1_n_0 ;
  wire \delay_cnt[4]_i_1_n_0 ;
  wire \delay_cnt[5]_i_1_n_0 ;
  wire \delay_cnt[6]_i_1_n_0 ;
  wire \delay_cnt[7]_i_1_n_0 ;
  wire \delay_cnt[8]_i_1_n_0 ;
  wire \delay_cnt[9]_i_1_n_0 ;
  wire delay_cnt_0;
  wire dut_n_0;
  wire dut_n_1;
  wire dut_n_5;
  wire dut_n_6;
  wire [15:1]in5;
  wire [5:1]p_0_in;
  wire penable_i_1_n_0;
  wire rst;
  wire [1:0]state;
  wire tx_busy_led;
  wire tx_out;
  wire [3:2]NLW_delay_cnt0_carry__2_CO_UNCONNECTED;
  wire [3:3]NLW_delay_cnt0_carry__2_O_UNCONNECTED;

  LUT3 #(
    .INIT(8'hBA)) 
    \FSM_onehot_state[4]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[3] ),
        .I1(\FSM_onehot_state[4]_i_2_n_0 ),
        .I2(\FSM_onehot_state_reg_n_0_[6] ),
        .O(\FSM_onehot_state[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \FSM_onehot_state[4]_i_2 
       (.I0(char_idx_reg[4]),
        .I1(char_idx_reg[3]),
        .I2(char_idx_reg[2]),
        .I3(char_idx_reg[5]),
        .I4(char_idx_reg[0]),
        .I5(char_idx_reg[1]),
        .O(\FSM_onehot_state[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hEFFFFFFFFFFFFFFF)) 
    \FSM_onehot_state[7]_inv_i_2 
       (.I0(char_idx_reg[1]),
        .I1(char_idx_reg[0]),
        .I2(char_idx_reg[5]),
        .I3(char_idx_reg[2]),
        .I4(\FSM_onehot_state[7]_inv_i_5_n_0 ),
        .I5(\FSM_onehot_state_reg_n_0_[6] ),
        .O(\FSM_onehot_state[7]_inv_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h0004)) 
    \FSM_onehot_state[7]_inv_i_4 
       (.I0(\FSM_onehot_state[7]_inv_i_6_n_0 ),
        .I1(\FSM_onehot_state[7]_inv_i_7_n_0 ),
        .I2(\FSM_onehot_state[7]_inv_i_8_n_0 ),
        .I3(\FSM_onehot_state[7]_inv_i_9_n_0 ),
        .O(\FSM_onehot_state[7]_inv_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \FSM_onehot_state[7]_inv_i_5 
       (.I0(char_idx_reg[3]),
        .I1(char_idx_reg[4]),
        .O(\FSM_onehot_state[7]_inv_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \FSM_onehot_state[7]_inv_i_6 
       (.I0(delay_cnt[4]),
        .I1(delay_cnt[3]),
        .I2(delay_cnt[2]),
        .I3(delay_cnt[5]),
        .O(\FSM_onehot_state[7]_inv_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \FSM_onehot_state[7]_inv_i_7 
       (.I0(delay_cnt[13]),
        .I1(delay_cnt[10]),
        .I2(delay_cnt[8]),
        .I3(delay_cnt[9]),
        .O(\FSM_onehot_state[7]_inv_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \FSM_onehot_state[7]_inv_i_8 
       (.I0(delay_cnt[12]),
        .I1(delay_cnt[14]),
        .I2(delay_cnt[0]),
        .I3(delay_cnt[11]),
        .O(\FSM_onehot_state[7]_inv_i_8_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \FSM_onehot_state[7]_inv_i_9 
       (.I0(delay_cnt[15]),
        .I1(delay_cnt[1]),
        .I2(delay_cnt[7]),
        .I3(delay_cnt[6]),
        .O(\FSM_onehot_state[7]_inv_i_9_n_0 ));
  (* FSM_ENCODED_STATES = "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000" *) 
  FDSE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(clk),
        .CE(dut_n_5),
        .D(1'b0),
        .Q(\FSM_onehot_state_reg_n_0_[0] ),
        .S(rst));
  (* FSM_ENCODED_STATES = "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(clk),
        .CE(dut_n_5),
        .D(\FSM_onehot_state_reg_n_0_[0] ),
        .Q(\FSM_onehot_state_reg_n_0_[1] ),
        .R(rst));
  (* FSM_ENCODED_STATES = "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(clk),
        .CE(dut_n_5),
        .D(\FSM_onehot_state_reg_n_0_[1] ),
        .Q(\FSM_onehot_state_reg_n_0_[2] ),
        .R(rst));
  (* FSM_ENCODED_STATES = "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[3] 
       (.C(clk),
        .CE(dut_n_5),
        .D(\FSM_onehot_state_reg_n_0_[2] ),
        .Q(\FSM_onehot_state_reg_n_0_[3] ),
        .R(rst));
  (* FSM_ENCODED_STATES = "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[4] 
       (.C(clk),
        .CE(dut_n_5),
        .D(\FSM_onehot_state[4]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg_n_0_[4] ),
        .R(rst));
  (* FSM_ENCODED_STATES = "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[5] 
       (.C(clk),
        .CE(dut_n_5),
        .D(\FSM_onehot_state_reg_n_0_[4] ),
        .Q(\FSM_onehot_state_reg_n_0_[5] ),
        .R(rst));
  (* FSM_ENCODED_STATES = "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[6] 
       (.C(clk),
        .CE(dut_n_5),
        .D(\FSM_onehot_state_reg_n_0_[5] ),
        .Q(\FSM_onehot_state_reg_n_0_[6] ),
        .R(rst));
  (* FSM_ENCODED_STATES = "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000" *) 
  (* inverted = "yes" *) 
  FDSE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[7]_inv 
       (.C(clk),
        .CE(dut_n_5),
        .D(\FSM_onehot_state[7]_inv_i_2_n_0 ),
        .Q(tx_busy_led),
        .S(rst));
  LUT1 #(
    .INIT(2'h1)) 
    \char_idx[0]_i_1 
       (.I0(char_idx_reg[0]),
        .O(\char_idx[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \char_idx[1]_i_1 
       (.I0(char_idx_reg[1]),
        .I1(char_idx_reg[0]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \char_idx[2]_i_1 
       (.I0(char_idx_reg[2]),
        .I1(char_idx_reg[1]),
        .I2(char_idx_reg[0]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \char_idx[3]_i_1 
       (.I0(char_idx_reg[3]),
        .I1(char_idx_reg[2]),
        .I2(char_idx_reg[0]),
        .I3(char_idx_reg[1]),
        .O(\char_idx[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \char_idx[4]_i_1 
       (.I0(char_idx_reg[4]),
        .I1(char_idx_reg[3]),
        .I2(char_idx_reg[1]),
        .I3(char_idx_reg[0]),
        .I4(char_idx_reg[2]),
        .O(p_0_in[4]));
  LUT3 #(
    .INIT(8'h20)) 
    \char_idx[5]_i_1 
       (.I0(\FSM_onehot_state[7]_inv_i_4_n_0 ),
        .I1(\FSM_onehot_state[4]_i_2_n_0 ),
        .I2(\FSM_onehot_state_reg_n_0_[6] ),
        .O(char_idx));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \char_idx[5]_i_2 
       (.I0(char_idx_reg[5]),
        .I1(char_idx_reg[1]),
        .I2(char_idx_reg[0]),
        .I3(char_idx_reg[2]),
        .I4(char_idx_reg[3]),
        .I5(char_idx_reg[4]),
        .O(p_0_in[5]));
  FDRE \char_idx_reg[0] 
       (.C(clk),
        .CE(char_idx),
        .D(\char_idx[0]_i_1_n_0 ),
        .Q(char_idx_reg[0]),
        .R(rst));
  FDRE \char_idx_reg[1] 
       (.C(clk),
        .CE(char_idx),
        .D(p_0_in[1]),
        .Q(char_idx_reg[1]),
        .R(rst));
  FDRE \char_idx_reg[2] 
       (.C(clk),
        .CE(char_idx),
        .D(p_0_in[2]),
        .Q(char_idx_reg[2]),
        .R(rst));
  FDRE \char_idx_reg[3] 
       (.C(clk),
        .CE(char_idx),
        .D(\char_idx[3]_i_1_n_0 ),
        .Q(char_idx_reg[3]),
        .R(rst));
  FDRE \char_idx_reg[4] 
       (.C(clk),
        .CE(char_idx),
        .D(p_0_in[4]),
        .Q(char_idx_reg[4]),
        .R(rst));
  FDRE \char_idx_reg[5] 
       (.C(clk),
        .CE(char_idx),
        .D(p_0_in[5]),
        .Q(char_idx_reg[5]),
        .R(rst));
  LUT3 #(
    .INIT(8'hFE)) 
    \cpu_paddr[13]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[4] ),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .I2(\FSM_onehot_state_reg_n_0_[0] ),
        .O(cpu_paddr[13]));
  LUT2 #(
    .INIT(4'hE)) 
    \cpu_paddr[3]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[4] ),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .O(cpu_paddr[3]));
  FDRE \cpu_paddr_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(cpu_paddr[13]),
        .Q(\cpu_paddr_reg_n_0_[13] ),
        .R(rst));
  FDRE \cpu_paddr_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_onehot_state_reg_n_0_[2] ),
        .Q(\cpu_paddr_reg_n_0_[2] ),
        .R(rst));
  FDRE \cpu_paddr_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(cpu_paddr[3]),
        .Q(\cpu_paddr_reg_n_0_[3] ),
        .R(rst));
  FDRE \cpu_paddr_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_onehot_state_reg_n_0_[0] ),
        .Q(\cpu_paddr_reg_n_0_[4] ),
        .R(rst));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'hFEEFEEEE)) 
    \cpu_wdata[0]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[2] ),
        .I1(\FSM_onehot_state_reg_n_0_[0] ),
        .I2(char_idx_reg[0]),
        .I3(\cpu_wdata[6]_i_2_n_0 ),
        .I4(\FSM_onehot_state_reg_n_0_[4] ),
        .O(\cpu_wdata[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hABFEEEBBAAAAAAAA)) 
    \cpu_wdata[1]_i_1 
       (.I0(\cpu_wdata[1]_i_2_n_0 ),
        .I1(\cpu_wdata[6]_i_3_n_0 ),
        .I2(\cpu_wdata[6]_i_2_n_0 ),
        .I3(char_idx_reg[1]),
        .I4(char_idx_reg[0]),
        .I5(\FSM_onehot_state_reg_n_0_[4] ),
        .O(\cpu_wdata[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \cpu_wdata[1]_i_2 
       (.I0(\FSM_onehot_state_reg_n_0_[0] ),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\cpu_wdata[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h2A80A00A2A80A802)) 
    \cpu_wdata[2]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[4] ),
        .I1(char_idx_reg[0]),
        .I2(char_idx_reg[1]),
        .I3(char_idx_reg[2]),
        .I4(\cpu_wdata[6]_i_3_n_0 ),
        .I5(\cpu_wdata[6]_i_2_n_0 ),
        .O(\cpu_wdata[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \cpu_wdata[3]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[0] ),
        .I1(\cpu_wdata[3]_i_2_n_0 ),
        .I2(\FSM_onehot_state_reg_n_0_[4] ),
        .O(\cpu_wdata[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hA942BD42A902FD08)) 
    \cpu_wdata[3]_i_2 
       (.I0(char_idx_reg[5]),
        .I1(char_idx_reg[1]),
        .I2(char_idx_reg[2]),
        .I3(char_idx_reg[3]),
        .I4(char_idx_reg[4]),
        .I5(char_idx_reg[0]),
        .O(\cpu_wdata[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hBA)) 
    \cpu_wdata[4]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[0] ),
        .I1(\cpu_wdata[4]_i_2_n_0 ),
        .I2(\FSM_onehot_state_reg_n_0_[4] ),
        .O(\cpu_wdata[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0002BFFD0002FFF5)) 
    \cpu_wdata[4]_i_2 
       (.I0(char_idx_reg[5]),
        .I1(char_idx_reg[1]),
        .I2(char_idx_reg[2]),
        .I3(char_idx_reg[3]),
        .I4(char_idx_reg[4]),
        .I5(char_idx_reg[0]),
        .O(\cpu_wdata[4]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \cpu_wdata[5]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[4] ),
        .I1(\cpu_wdata[6]_i_2_n_0 ),
        .O(\cpu_wdata[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \cpu_wdata[6]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[4] ),
        .I1(\cpu_wdata[6]_i_2_n_0 ),
        .I2(\cpu_wdata[6]_i_3_n_0 ),
        .O(\cpu_wdata[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAA8AAA8AAA8)) 
    \cpu_wdata[6]_i_2 
       (.I0(char_idx_reg[5]),
        .I1(char_idx_reg[3]),
        .I2(char_idx_reg[4]),
        .I3(char_idx_reg[2]),
        .I4(char_idx_reg[1]),
        .I5(char_idx_reg[0]),
        .O(\cpu_wdata[6]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h01555555)) 
    \cpu_wdata[6]_i_3 
       (.I0(char_idx_reg[5]),
        .I1(char_idx_reg[1]),
        .I2(char_idx_reg[2]),
        .I3(char_idx_reg[3]),
        .I4(char_idx_reg[4]),
        .O(\cpu_wdata[6]_i_3_n_0 ));
  FDRE \cpu_wdata_reg[0] 
       (.C(clk),
        .CE(cpu_paddr[13]),
        .D(\cpu_wdata[0]_i_1_n_0 ),
        .Q(\cpu_wdata_reg_n_0_[0] ),
        .R(rst));
  FDRE \cpu_wdata_reg[1] 
       (.C(clk),
        .CE(cpu_paddr[13]),
        .D(\cpu_wdata[1]_i_1_n_0 ),
        .Q(\cpu_wdata_reg_n_0_[1] ),
        .R(rst));
  FDRE \cpu_wdata_reg[2] 
       (.C(clk),
        .CE(cpu_paddr[13]),
        .D(\cpu_wdata[2]_i_1_n_0 ),
        .Q(\cpu_wdata_reg_n_0_[2] ),
        .R(rst));
  FDRE \cpu_wdata_reg[3] 
       (.C(clk),
        .CE(cpu_paddr[13]),
        .D(\cpu_wdata[3]_i_1_n_0 ),
        .Q(\cpu_wdata_reg_n_0_[3] ),
        .R(rst));
  FDRE \cpu_wdata_reg[4] 
       (.C(clk),
        .CE(cpu_paddr[13]),
        .D(\cpu_wdata[4]_i_1_n_0 ),
        .Q(\cpu_wdata_reg_n_0_[4] ),
        .R(rst));
  FDRE \cpu_wdata_reg[5] 
       (.C(clk),
        .CE(cpu_paddr[13]),
        .D(\cpu_wdata[5]_i_1_n_0 ),
        .Q(\cpu_wdata_reg_n_0_[5] ),
        .R(rst));
  FDRE \cpu_wdata_reg[6] 
       (.C(clk),
        .CE(cpu_paddr[13]),
        .D(\cpu_wdata[6]_i_1_n_0 ),
        .Q(\cpu_wdata_reg_n_0_[6] ),
        .R(rst));
  FDRE cpu_write_reg
       (.C(clk),
        .CE(1'b1),
        .D(dut_n_6),
        .Q(cpu_write_reg_n_0),
        .R(rst));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 delay_cnt0_carry
       (.CI(1'b0),
        .CO({delay_cnt0_carry_n_0,delay_cnt0_carry_n_1,delay_cnt0_carry_n_2,delay_cnt0_carry_n_3}),
        .CYINIT(delay_cnt[0]),
        .DI(delay_cnt[4:1]),
        .O(in5[4:1]),
        .S({delay_cnt0_carry_i_1_n_0,delay_cnt0_carry_i_2_n_0,delay_cnt0_carry_i_3_n_0,delay_cnt0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 delay_cnt0_carry__0
       (.CI(delay_cnt0_carry_n_0),
        .CO({delay_cnt0_carry__0_n_0,delay_cnt0_carry__0_n_1,delay_cnt0_carry__0_n_2,delay_cnt0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(delay_cnt[8:5]),
        .O(in5[8:5]),
        .S({delay_cnt0_carry__0_i_1_n_0,delay_cnt0_carry__0_i_2_n_0,delay_cnt0_carry__0_i_3_n_0,delay_cnt0_carry__0_i_4_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__0_i_1
       (.I0(delay_cnt[8]),
        .O(delay_cnt0_carry__0_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__0_i_2
       (.I0(delay_cnt[7]),
        .O(delay_cnt0_carry__0_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__0_i_3
       (.I0(delay_cnt[6]),
        .O(delay_cnt0_carry__0_i_3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__0_i_4
       (.I0(delay_cnt[5]),
        .O(delay_cnt0_carry__0_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 delay_cnt0_carry__1
       (.CI(delay_cnt0_carry__0_n_0),
        .CO({delay_cnt0_carry__1_n_0,delay_cnt0_carry__1_n_1,delay_cnt0_carry__1_n_2,delay_cnt0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(delay_cnt[12:9]),
        .O(in5[12:9]),
        .S({delay_cnt0_carry__1_i_1_n_0,delay_cnt0_carry__1_i_2_n_0,delay_cnt0_carry__1_i_3_n_0,delay_cnt0_carry__1_i_4_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__1_i_1
       (.I0(delay_cnt[12]),
        .O(delay_cnt0_carry__1_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__1_i_2
       (.I0(delay_cnt[11]),
        .O(delay_cnt0_carry__1_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__1_i_3
       (.I0(delay_cnt[10]),
        .O(delay_cnt0_carry__1_i_3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__1_i_4
       (.I0(delay_cnt[9]),
        .O(delay_cnt0_carry__1_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 delay_cnt0_carry__2
       (.CI(delay_cnt0_carry__1_n_0),
        .CO({NLW_delay_cnt0_carry__2_CO_UNCONNECTED[3:2],delay_cnt0_carry__2_n_2,delay_cnt0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,delay_cnt[14:13]}),
        .O({NLW_delay_cnt0_carry__2_O_UNCONNECTED[3],in5[15:13]}),
        .S({1'b0,delay_cnt0_carry__2_i_1_n_0,delay_cnt0_carry__2_i_2_n_0,delay_cnt0_carry__2_i_3_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__2_i_1
       (.I0(delay_cnt[15]),
        .O(delay_cnt0_carry__2_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__2_i_2
       (.I0(delay_cnt[14]),
        .O(delay_cnt0_carry__2_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry__2_i_3
       (.I0(delay_cnt[13]),
        .O(delay_cnt0_carry__2_i_3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry_i_1
       (.I0(delay_cnt[4]),
        .O(delay_cnt0_carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry_i_2
       (.I0(delay_cnt[3]),
        .O(delay_cnt0_carry_i_2_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry_i_3
       (.I0(delay_cnt[2]),
        .O(delay_cnt0_carry_i_3_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    delay_cnt0_carry_i_4
       (.I0(delay_cnt[1]),
        .O(delay_cnt0_carry_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \delay_cnt[0]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(delay_cnt[0]),
        .O(\delay_cnt[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[10]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[10]),
        .O(\delay_cnt[10]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[11]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[11]),
        .O(\delay_cnt[11]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \delay_cnt[12]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[5] ),
        .I1(in5[12]),
        .I2(\FSM_onehot_state_reg_n_0_[6] ),
        .O(\delay_cnt[12]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[13]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[13]),
        .O(\delay_cnt[13]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[14]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[14]),
        .O(\delay_cnt[14]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[15]_i_2 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[15]),
        .O(\delay_cnt[15]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[1]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[1]),
        .O(\delay_cnt[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[2]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[2]),
        .O(\delay_cnt[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \delay_cnt[3]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[5] ),
        .I1(in5[3]),
        .I2(\FSM_onehot_state_reg_n_0_[6] ),
        .O(\delay_cnt[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[4]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[4]),
        .O(\delay_cnt[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[5]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[5]),
        .O(\delay_cnt[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \delay_cnt[6]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[6] ),
        .I1(in5[6]),
        .O(\delay_cnt[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \delay_cnt[7]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[5] ),
        .I1(in5[7]),
        .I2(\FSM_onehot_state_reg_n_0_[6] ),
        .O(\delay_cnt[7]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \delay_cnt[8]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[5] ),
        .I1(in5[8]),
        .I2(\FSM_onehot_state_reg_n_0_[6] ),
        .O(\delay_cnt[8]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \delay_cnt[9]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[5] ),
        .I1(in5[9]),
        .I2(\FSM_onehot_state_reg_n_0_[6] ),
        .O(\delay_cnt[9]_i_1_n_0 ));
  FDRE \delay_cnt_reg[0] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[0]_i_1_n_0 ),
        .Q(delay_cnt[0]),
        .R(rst));
  FDRE \delay_cnt_reg[10] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[10]_i_1_n_0 ),
        .Q(delay_cnt[10]),
        .R(rst));
  FDRE \delay_cnt_reg[11] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[11]_i_1_n_0 ),
        .Q(delay_cnt[11]),
        .R(rst));
  FDRE \delay_cnt_reg[12] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[12]_i_1_n_0 ),
        .Q(delay_cnt[12]),
        .R(rst));
  FDRE \delay_cnt_reg[13] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[13]_i_1_n_0 ),
        .Q(delay_cnt[13]),
        .R(rst));
  FDRE \delay_cnt_reg[14] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[14]_i_1_n_0 ),
        .Q(delay_cnt[14]),
        .R(rst));
  FDRE \delay_cnt_reg[15] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[15]_i_2_n_0 ),
        .Q(delay_cnt[15]),
        .R(rst));
  FDRE \delay_cnt_reg[1] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[1]_i_1_n_0 ),
        .Q(delay_cnt[1]),
        .R(rst));
  FDRE \delay_cnt_reg[2] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[2]_i_1_n_0 ),
        .Q(delay_cnt[2]),
        .R(rst));
  FDRE \delay_cnt_reg[3] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[3]_i_1_n_0 ),
        .Q(delay_cnt[3]),
        .R(rst));
  FDRE \delay_cnt_reg[4] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[4]_i_1_n_0 ),
        .Q(delay_cnt[4]),
        .R(rst));
  FDRE \delay_cnt_reg[5] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[5]_i_1_n_0 ),
        .Q(delay_cnt[5]),
        .R(rst));
  FDRE \delay_cnt_reg[6] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[6]_i_1_n_0 ),
        .Q(delay_cnt[6]),
        .R(rst));
  FDRE \delay_cnt_reg[7] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[7]_i_1_n_0 ),
        .Q(delay_cnt[7]),
        .R(rst));
  FDRE \delay_cnt_reg[8] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[8]_i_1_n_0 ),
        .Q(delay_cnt[8]),
        .R(rst));
  FDRE \delay_cnt_reg[9] 
       (.C(clk),
        .CE(delay_cnt_0),
        .D(\delay_cnt[9]_i_1_n_0 ),
        .Q(delay_cnt[9]),
        .R(rst));
  design1_hw_apb_uart_tb_0_0_apb_interface dut
       (.E(delay_cnt_0),
        .\FSM_onehot_state_reg[1] (dut_n_6),
        .\FSM_onehot_state_reg[6] (dut_n_5),
        .Q({\FSM_onehot_state_reg_n_0_[6] ,\FSM_onehot_state_reg_n_0_[5] ,\FSM_onehot_state_reg_n_0_[3] ,\FSM_onehot_state_reg_n_0_[1] }),
        .clk(clk),
        .cpu_write_reg(cpu_paddr[13]),
        .\delay_cnt_reg[0] (\FSM_onehot_state[7]_inv_i_4_n_0 ),
        .\paddr_reg[6]_0 ({\cpu_paddr_reg_n_0_[13] ,\cpu_paddr_reg_n_0_[4] ,\cpu_paddr_reg_n_0_[3] ,\cpu_paddr_reg_n_0_[2] }),
        .penable_reg_0(dut_n_0),
        .penable_reg_1(penable_i_1_n_0),
        .\psel_reg[1]_0 (dut_n_1),
        .\pwdata_reg[6]_0 ({\cpu_wdata_reg_n_0_[6] ,\cpu_wdata_reg_n_0_[5] ,\cpu_wdata_reg_n_0_[4] ,\cpu_wdata_reg_n_0_[3] ,\cpu_wdata_reg_n_0_[2] ,\cpu_wdata_reg_n_0_[1] ,\cpu_wdata_reg_n_0_[0] }),
        .pwrite_reg_0(cpu_write_reg_n_0),
        .rst(rst),
        .state(state),
        .tx_out(tx_out));
  LUT4 #(
    .INIT(16'h8860)) 
    penable_i_1
       (.I0(state[0]),
        .I1(state[1]),
        .I2(dut_n_1),
        .I3(dut_n_0),
        .O(penable_i_1_n_0));
endmodule

(* ORIG_REF_NAME = "uart_top" *) 
module design1_hw_apb_uart_tb_0_0_uart_top
   (tx_out,
    Q,
    clk,
    rst,
    \TDR_reg_reg[6] ,
    \CR1_reg_reg[0] ,
    \CR1_reg_reg[0]_0 ,
    \CR1_reg_reg[0]_1 );
  output tx_out;
  input [3:0]Q;
  input clk;
  input rst;
  input [6:0]\TDR_reg_reg[6] ;
  input \CR1_reg_reg[0] ;
  input \CR1_reg_reg[0]_0 ;
  input \CR1_reg_reg[0]_1 ;

  wire \CR1_reg_reg[0] ;
  wire \CR1_reg_reg[0]_0 ;
  wire \CR1_reg_reg[0]_1 ;
  wire [3:0]Q;
  wire [6:0]\TDR_reg_reg[6] ;
  wire clk;
  wire rst;
  wire tx_out;

  design1_hw_apb_uart_tb_0_0_UART_module core_uart
       (.\CR1_reg_reg[0]_0 (\CR1_reg_reg[0] ),
        .\CR1_reg_reg[0]_1 (\CR1_reg_reg[0]_0 ),
        .\CR1_reg_reg[0]_2 (\CR1_reg_reg[0]_1 ),
        .Q(Q),
        .\TDR_reg_reg[6]_0 (\TDR_reg_reg[6] ),
        .clk(clk),
        .rst(rst),
        .tx_out(tx_out));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
