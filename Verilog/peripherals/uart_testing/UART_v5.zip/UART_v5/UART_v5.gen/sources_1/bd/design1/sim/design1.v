//Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
//Date        : Thu Apr  9 22:56:01 2026
//Host        : DELL-LAPTOP running 64-bit major release  (build 9200)
//Command     : generate_target design1.bd
//Design      : design1
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design1,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=2,numReposBlks=2,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=1,numPkgbdBlks=0,bdsource=USER,da_board_cnt=2,da_clkrst_cnt=1,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "design1.hwdef" *) 
module design1
   (reset_rtl,
    sys_clock,
    tester_led,
    tester_reset,
    tester_rx,
    tester_tx);
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESET_RTL RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESET_RTL, INSERT_VIP 0, POLARITY ACTIVE_HIGH" *) input reset_rtl;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.SYS_CLOCK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.SYS_CLOCK, CLK_DOMAIN design1_sys_clock, FREQ_HZ 125000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.000" *) input sys_clock;
  output tester_led;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.TESTER_RESET RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.TESTER_RESET, INSERT_VIP 0, POLARITY ACTIVE_HIGH" *) input tester_reset;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.TESTER_RX DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.TESTER_RX, LAYERED_METADATA undef" *) input tester_rx;
  (* X_INTERFACE_INFO = "xilinx.com:signal:data:1.0 DATA.TESTER_TX DATA" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DATA.TESTER_TX, LAYERED_METADATA undef" *) output tester_tx;

  wire clk_wiz_clk_out1;
  wire hw_apb_uart_tb_0_tx_busy_led;
  wire hw_apb_uart_tb_0_tx_out;
  wire reset_rtl_1;
  wire sys_clock_1;
  wire tester_reset_1;
  wire tester_rx_1;

  assign reset_rtl_1 = reset_rtl;
  assign sys_clock_1 = sys_clock;
  assign tester_led = hw_apb_uart_tb_0_tx_busy_led;
  assign tester_reset_1 = tester_reset;
  assign tester_rx_1 = tester_rx;
  assign tester_tx = hw_apb_uart_tb_0_tx_out;
  design1_clk_wiz_0 clk_wiz
       (.clk_in1(sys_clock_1),
        .clk_out1(clk_wiz_clk_out1),
        .reset(reset_rtl_1));
  design1_hw_apb_uart_tb_0_0 hw_apb_uart_tb_0
       (.clk(clk_wiz_clk_out1),
        .rst(tester_reset_1),
        .rx(tester_rx_1),
        .tx_busy_led(hw_apb_uart_tb_0_tx_busy_led),
        .tx_out(hw_apb_uart_tb_0_tx_out));
endmodule
