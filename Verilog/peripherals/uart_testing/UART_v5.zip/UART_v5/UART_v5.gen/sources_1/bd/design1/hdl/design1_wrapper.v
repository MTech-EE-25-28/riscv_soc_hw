//Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
//Date        : Thu Apr  9 22:56:01 2026
//Host        : DELL-LAPTOP running 64-bit major release  (build 9200)
//Command     : generate_target design1_wrapper.bd
//Design      : design1_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module design1_wrapper
   (reset_rtl,
    sys_clock,
    tester_led,
    tester_reset,
    tester_rx,
    tester_tx);
  input reset_rtl;
  input sys_clock;
  output tester_led;
  input tester_reset;
  input tester_rx;
  output tester_tx;

  wire reset_rtl;
  wire sys_clock;
  wire tester_led;
  wire tester_reset;
  wire tester_rx;
  wire tester_tx;

  design1 design1_i
       (.reset_rtl(reset_rtl),
        .sys_clock(sys_clock),
        .tester_led(tester_led),
        .tester_reset(tester_reset),
        .tester_rx(tester_rx),
        .tester_tx(tester_tx));
endmodule
