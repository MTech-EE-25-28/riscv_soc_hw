-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Thu Apr  9 22:57:15 2026
-- Host        : DELL-LAPTOP running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design1_hw_apb_uart_tb_0_0_sim_netlist.vhdl
-- Design      : design1_hw_apb_uart_tb_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_baud_rate_gen is
  port (
    baud_tick_reg_0 : out STD_LOGIC;
    \CR1_reg_reg[4]\ : out STD_LOGIC;
    \FSM_sequential_tx_state_reg[2]\ : out STD_LOGIC;
    E : out STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_sequential_tx_state_reg[1]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_sequential_tx_state_reg[2]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_sequential_tx_state_reg[2]_1\ : out STD_LOGIC;
    \FSM_sequential_tx_state_reg[0]\ : out STD_LOGIC;
    clk : in STD_LOGIC;
    rst : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \tx_state__0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \FSM_sequential_tx_state_reg[2]_2\ : in STD_LOGIC;
    \FSM_sequential_tx_state_reg[2]_3\ : in STD_LOGIC;
    \FSM_sequential_tx_state_reg[1]_0\ : in STD_LOGIC;
    \FSM_sequential_tx_state_reg[0]_0\ : in STD_LOGIC;
    sr_out_wire : in STD_LOGIC_VECTOR ( 0 to 0 );
    \tx_bit_ptr_reg[0]\ : in STD_LOGIC;
    \tx_bit_ptr_reg[0]_0\ : in STD_LOGIC;
    txe_flag_reg : in STD_LOGIC;
    txe_flag_reg_0 : in STD_LOGIC;
    tx_reg : in STD_LOGIC;
    tx_reg_0 : in STD_LOGIC;
    tx_reg_1 : in STD_LOGIC;
    tx_out : in STD_LOGIC;
    baud_tick_reg_1 : in STD_LOGIC_VECTOR ( 6 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_baud_rate_gen;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_baud_rate_gen is
  signal baud_tick_16x : STD_LOGIC;
  signal baud_tick_i_2_n_0 : STD_LOGIC;
  signal \counter1_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_0\ : STD_LOGIC;
  signal \counter1_carry__0_n_1\ : STD_LOGIC;
  signal \counter1_carry__0_n_2\ : STD_LOGIC;
  signal \counter1_carry__0_n_3\ : STD_LOGIC;
  signal \counter1_carry__1_n_2\ : STD_LOGIC;
  signal \counter1_carry__1_n_3\ : STD_LOGIC;
  signal counter1_carry_i_1_n_0 : STD_LOGIC;
  signal counter1_carry_i_2_n_0 : STD_LOGIC;
  signal counter1_carry_i_3_n_0 : STD_LOGIC;
  signal counter1_carry_i_4_n_0 : STD_LOGIC;
  signal counter1_carry_n_0 : STD_LOGIC;
  signal counter1_carry_n_1 : STD_LOGIC;
  signal counter1_carry_n_2 : STD_LOGIC;
  signal counter1_carry_n_3 : STD_LOGIC;
  signal counter2 : STD_LOGIC_VECTOR ( 6 downto 1 );
  signal \counter2_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \counter2_carry__0_n_1\ : STD_LOGIC;
  signal \counter2_carry__0_n_3\ : STD_LOGIC;
  signal counter2_carry_i_1_n_0 : STD_LOGIC;
  signal counter2_carry_i_2_n_0 : STD_LOGIC;
  signal counter2_carry_i_3_n_0 : STD_LOGIC;
  signal counter2_carry_i_4_n_0 : STD_LOGIC;
  signal counter2_carry_n_0 : STD_LOGIC;
  signal counter2_carry_n_1 : STD_LOGIC;
  signal counter2_carry_n_2 : STD_LOGIC;
  signal counter2_carry_n_3 : STD_LOGIC;
  signal \counter[0]_i_2_n_0\ : STD_LOGIC;
  signal \counter[0]_i_3_n_0\ : STD_LOGIC;
  signal \counter[0]_i_4_n_0\ : STD_LOGIC;
  signal \counter[0]_i_5_n_0\ : STD_LOGIC;
  signal \counter[0]_i_6_n_0\ : STD_LOGIC;
  signal \counter[12]_i_2_n_0\ : STD_LOGIC;
  signal \counter[12]_i_3_n_0\ : STD_LOGIC;
  signal \counter[12]_i_4_n_0\ : STD_LOGIC;
  signal \counter[12]_i_5_n_0\ : STD_LOGIC;
  signal \counter[4]_i_2_n_0\ : STD_LOGIC;
  signal \counter[4]_i_3_n_0\ : STD_LOGIC;
  signal \counter[4]_i_4_n_0\ : STD_LOGIC;
  signal \counter[4]_i_5_n_0\ : STD_LOGIC;
  signal \counter[8]_i_2_n_0\ : STD_LOGIC;
  signal \counter[8]_i_3_n_0\ : STD_LOGIC;
  signal \counter[8]_i_4_n_0\ : STD_LOGIC;
  signal \counter[8]_i_5_n_0\ : STD_LOGIC;
  signal counter_reg : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \counter_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[0]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[0]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[0]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[0]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[0]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[0]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[0]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[12]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \counter_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal load : STD_LOGIC;
  signal sel : STD_LOGIC;
  signal \tx_bit_ptr[3]_i_3_n_0\ : STD_LOGIC;
  signal tx_i_5_n_0 : STD_LOGIC;
  signal NLW_counter1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter1_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_counter1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_counter2_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_counter2_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_counter_reg[12]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \counter_reg[0]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \counter_reg[12]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \counter_reg[4]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \counter_reg[8]_i_1\ : label is 11;
begin
\FSM_sequential_tx_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FF000001000000"
    )
        port map (
      I0 => \tx_state__0\(2),
      I1 => \FSM_sequential_tx_state_reg[0]_0\,
      I2 => \FSM_sequential_tx_state_reg[2]_3\,
      I3 => baud_tick_16x,
      I4 => \FSM_sequential_tx_state_reg[1]_0\,
      I5 => \tx_state__0\(0),
      O => \FSM_sequential_tx_state_reg[2]\
    );
\FSM_sequential_tx_state[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F2FF00000C000000"
    )
        port map (
      I0 => Q(2),
      I1 => \tx_state__0\(0),
      I2 => \FSM_sequential_tx_state_reg[2]_3\,
      I3 => baud_tick_16x,
      I4 => \FSM_sequential_tx_state_reg[1]_0\,
      I5 => \tx_state__0\(1),
      O => \CR1_reg_reg[4]\
    );
\FSM_sequential_tx_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DF00000010000000"
    )
        port map (
      I0 => \FSM_sequential_tx_state_reg[2]_2\,
      I1 => \FSM_sequential_tx_state_reg[2]_3\,
      I2 => baud_tick_16x,
      I3 => Q(0),
      I4 => Q(1),
      I5 => \tx_state__0\(2),
      O => baud_tick_reg_0
    );
baud_tick_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => baud_tick_i_2_n_0,
      I1 => baud_tick_reg_1(0),
      O => sel
    );
baud_tick_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => baud_tick_reg_1(3),
      I1 => baud_tick_reg_1(4),
      I2 => baud_tick_reg_1(1),
      I3 => baud_tick_reg_1(2),
      I4 => baud_tick_reg_1(6),
      I5 => baud_tick_reg_1(5),
      O => baud_tick_i_2_n_0
    );
baud_tick_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => load,
      Q => baud_tick_16x
    );
counter1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter1_carry_n_0,
      CO(2) => counter1_carry_n_1,
      CO(1) => counter1_carry_n_2,
      CO(0) => counter1_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_counter1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => counter1_carry_i_1_n_0,
      S(2) => counter1_carry_i_2_n_0,
      S(1) => counter1_carry_i_3_n_0,
      S(0) => counter1_carry_i_4_n_0
    );
\counter1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter1_carry_n_0,
      CO(3) => \counter1_carry__0_n_0\,
      CO(2) => \counter1_carry__0_n_1\,
      CO(1) => \counter1_carry__0_n_2\,
      CO(0) => \counter1_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_counter1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \counter2_carry__0_n_1\,
      S(2) => \counter2_carry__0_n_1\,
      S(1) => \counter1_carry__0_i_1_n_0\,
      S(0) => \counter1_carry__0_i_2_n_0\
    );
\counter1_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => counter_reg(15),
      I1 => \counter2_carry__0_n_1\,
      O => \counter1_carry__0_i_1_n_0\
    );
\counter1_carry__0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2004"
    )
        port map (
      I0 => counter_reg(12),
      I1 => \counter2_carry__0_n_1\,
      I2 => counter_reg(14),
      I3 => counter_reg(13),
      O => \counter1_carry__0_i_2_n_0\
    );
\counter1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter1_carry__0_n_0\,
      CO(3) => \NLW_counter1_carry__1_CO_UNCONNECTED\(3),
      CO(2) => load,
      CO(1) => \counter1_carry__1_n_2\,
      CO(0) => \counter1_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_counter1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \counter2_carry__0_n_1\,
      S(1) => \counter2_carry__0_n_1\,
      S(0) => \counter2_carry__0_n_1\
    );
counter1_carry_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2004"
    )
        port map (
      I0 => counter_reg(9),
      I1 => \counter2_carry__0_n_1\,
      I2 => counter_reg(11),
      I3 => counter_reg(10),
      O => counter1_carry_i_1_n_0
    );
counter1_carry_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"09000090"
    )
        port map (
      I0 => counter_reg(6),
      I1 => counter2(6),
      I2 => \counter2_carry__0_n_1\,
      I3 => counter_reg(8),
      I4 => counter_reg(7),
      O => counter1_carry_i_2_n_0
    );
counter1_carry_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => counter_reg(3),
      I1 => counter2(3),
      I2 => counter2(5),
      I3 => counter_reg(5),
      I4 => counter2(4),
      I5 => counter_reg(4),
      O => counter1_carry_i_3_n_0
    );
counter1_carry_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6006000000006006"
    )
        port map (
      I0 => counter_reg(0),
      I1 => baud_tick_reg_1(0),
      I2 => counter2(2),
      I3 => counter_reg(2),
      I4 => counter2(1),
      I5 => counter_reg(1),
      O => counter1_carry_i_4_n_0
    );
counter2_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => counter2_carry_n_0,
      CO(2) => counter2_carry_n_1,
      CO(1) => counter2_carry_n_2,
      CO(0) => counter2_carry_n_3,
      CYINIT => baud_tick_reg_1(0),
      DI(3 downto 0) => baud_tick_reg_1(4 downto 1),
      O(3 downto 0) => counter2(4 downto 1),
      S(3) => counter2_carry_i_1_n_0,
      S(2) => counter2_carry_i_2_n_0,
      S(1) => counter2_carry_i_3_n_0,
      S(0) => counter2_carry_i_4_n_0
    );
\counter2_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => counter2_carry_n_0,
      CO(3) => \NLW_counter2_carry__0_CO_UNCONNECTED\(3),
      CO(2) => \counter2_carry__0_n_1\,
      CO(1) => \NLW_counter2_carry__0_CO_UNCONNECTED\(1),
      CO(0) => \counter2_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => baud_tick_reg_1(6 downto 5),
      O(3 downto 2) => \NLW_counter2_carry__0_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => counter2(6 downto 5),
      S(3 downto 2) => B"01",
      S(1) => \counter2_carry__0_i_1_n_0\,
      S(0) => \counter2_carry__0_i_2_n_0\
    );
\counter2_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => baud_tick_reg_1(6),
      O => \counter2_carry__0_i_1_n_0\
    );
\counter2_carry__0_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => baud_tick_reg_1(5),
      O => \counter2_carry__0_i_2_n_0\
    );
counter2_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => baud_tick_reg_1(4),
      O => counter2_carry_i_1_n_0
    );
counter2_carry_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => baud_tick_reg_1(3),
      O => counter2_carry_i_2_n_0
    );
counter2_carry_i_3: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => baud_tick_reg_1(2),
      O => counter2_carry_i_3_n_0
    );
counter2_carry_i_4: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => baud_tick_reg_1(1),
      O => counter2_carry_i_4_n_0
    );
\counter[0]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(0),
      I1 => load,
      O => \counter[0]_i_2_n_0\
    );
\counter[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(3),
      I1 => load,
      O => \counter[0]_i_3_n_0\
    );
\counter[0]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(2),
      I1 => load,
      O => \counter[0]_i_4_n_0\
    );
\counter[0]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(1),
      I1 => load,
      O => \counter[0]_i_5_n_0\
    );
\counter[0]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => counter_reg(0),
      I1 => load,
      O => \counter[0]_i_6_n_0\
    );
\counter[12]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(15),
      I1 => load,
      O => \counter[12]_i_2_n_0\
    );
\counter[12]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(14),
      I1 => load,
      O => \counter[12]_i_3_n_0\
    );
\counter[12]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(13),
      I1 => load,
      O => \counter[12]_i_4_n_0\
    );
\counter[12]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(12),
      I1 => load,
      O => \counter[12]_i_5_n_0\
    );
\counter[4]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(7),
      I1 => load,
      O => \counter[4]_i_2_n_0\
    );
\counter[4]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(6),
      I1 => load,
      O => \counter[4]_i_3_n_0\
    );
\counter[4]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(5),
      I1 => load,
      O => \counter[4]_i_4_n_0\
    );
\counter[4]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(4),
      I1 => load,
      O => \counter[4]_i_5_n_0\
    );
\counter[8]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(11),
      I1 => load,
      O => \counter[8]_i_2_n_0\
    );
\counter[8]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(10),
      I1 => load,
      O => \counter[8]_i_3_n_0\
    );
\counter[8]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(9),
      I1 => load,
      O => \counter[8]_i_4_n_0\
    );
\counter[8]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => counter_reg(8),
      I1 => load,
      O => \counter[8]_i_5_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[0]_i_1_n_7\,
      Q => counter_reg(0)
    );
\counter_reg[0]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \counter_reg[0]_i_1_n_0\,
      CO(2) => \counter_reg[0]_i_1_n_1\,
      CO(1) => \counter_reg[0]_i_1_n_2\,
      CO(0) => \counter_reg[0]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \counter[0]_i_2_n_0\,
      O(3) => \counter_reg[0]_i_1_n_4\,
      O(2) => \counter_reg[0]_i_1_n_5\,
      O(1) => \counter_reg[0]_i_1_n_6\,
      O(0) => \counter_reg[0]_i_1_n_7\,
      S(3) => \counter[0]_i_3_n_0\,
      S(2) => \counter[0]_i_4_n_0\,
      S(1) => \counter[0]_i_5_n_0\,
      S(0) => \counter[0]_i_6_n_0\
    );
\counter_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[8]_i_1_n_5\,
      Q => counter_reg(10)
    );
\counter_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[8]_i_1_n_4\,
      Q => counter_reg(11)
    );
\counter_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[12]_i_1_n_7\,
      Q => counter_reg(12)
    );
\counter_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[8]_i_1_n_0\,
      CO(3) => \NLW_counter_reg[12]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \counter_reg[12]_i_1_n_1\,
      CO(1) => \counter_reg[12]_i_1_n_2\,
      CO(0) => \counter_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[12]_i_1_n_4\,
      O(2) => \counter_reg[12]_i_1_n_5\,
      O(1) => \counter_reg[12]_i_1_n_6\,
      O(0) => \counter_reg[12]_i_1_n_7\,
      S(3) => \counter[12]_i_2_n_0\,
      S(2) => \counter[12]_i_3_n_0\,
      S(1) => \counter[12]_i_4_n_0\,
      S(0) => \counter[12]_i_5_n_0\
    );
\counter_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[12]_i_1_n_6\,
      Q => counter_reg(13)
    );
\counter_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[12]_i_1_n_5\,
      Q => counter_reg(14)
    );
\counter_reg[15]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[12]_i_1_n_4\,
      Q => counter_reg(15)
    );
\counter_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[0]_i_1_n_6\,
      Q => counter_reg(1)
    );
\counter_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[0]_i_1_n_5\,
      Q => counter_reg(2)
    );
\counter_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[0]_i_1_n_4\,
      Q => counter_reg(3)
    );
\counter_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[4]_i_1_n_7\,
      Q => counter_reg(4)
    );
\counter_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[0]_i_1_n_0\,
      CO(3) => \counter_reg[4]_i_1_n_0\,
      CO(2) => \counter_reg[4]_i_1_n_1\,
      CO(1) => \counter_reg[4]_i_1_n_2\,
      CO(0) => \counter_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[4]_i_1_n_4\,
      O(2) => \counter_reg[4]_i_1_n_5\,
      O(1) => \counter_reg[4]_i_1_n_6\,
      O(0) => \counter_reg[4]_i_1_n_7\,
      S(3) => \counter[4]_i_2_n_0\,
      S(2) => \counter[4]_i_3_n_0\,
      S(1) => \counter[4]_i_4_n_0\,
      S(0) => \counter[4]_i_5_n_0\
    );
\counter_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[4]_i_1_n_6\,
      Q => counter_reg(5)
    );
\counter_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[4]_i_1_n_5\,
      Q => counter_reg(6)
    );
\counter_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[4]_i_1_n_4\,
      Q => counter_reg(7)
    );
\counter_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[8]_i_1_n_7\,
      Q => counter_reg(8)
    );
\counter_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \counter_reg[4]_i_1_n_0\,
      CO(3) => \counter_reg[8]_i_1_n_0\,
      CO(2) => \counter_reg[8]_i_1_n_1\,
      CO(1) => \counter_reg[8]_i_1_n_2\,
      CO(0) => \counter_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \counter_reg[8]_i_1_n_4\,
      O(2) => \counter_reg[8]_i_1_n_5\,
      O(1) => \counter_reg[8]_i_1_n_6\,
      O(0) => \counter_reg[8]_i_1_n_7\,
      S(3) => \counter[8]_i_2_n_0\,
      S(2) => \counter[8]_i_3_n_0\,
      S(1) => \counter[8]_i_4_n_0\,
      S(0) => \counter[8]_i_5_n_0\
    );
\counter_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => sel,
      CLR => rst,
      D => \counter_reg[8]_i_1_n_6\,
      Q => counter_reg(9)
    );
\tx_bit_ptr[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000222000000200"
    )
        port map (
      I0 => \tx_bit_ptr[3]_i_3_n_0\,
      I1 => \tx_bit_ptr_reg[0]\,
      I2 => \tx_state__0\(1),
      I3 => \tx_state__0\(0),
      I4 => \tx_state__0\(2),
      I5 => \tx_bit_ptr_reg[0]_0\,
      O => \FSM_sequential_tx_state_reg[1]\(0)
    );
\tx_bit_ptr[3]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => Q(0),
      I1 => Q(1),
      I2 => baud_tick_16x,
      O => \tx_bit_ptr[3]_i_3_n_0\
    );
tx_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A88FFFF8A880000"
    )
        port map (
      I0 => tx_reg,
      I1 => tx_reg_0,
      I2 => tx_reg_1,
      I3 => \tx_state__0\(0),
      I4 => tx_i_5_n_0,
      I5 => tx_out,
      O => \FSM_sequential_tx_state_reg[0]\
    );
tx_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1F00FFFFFFFFFFFF"
    )
        port map (
      I0 => \tx_state__0\(0),
      I1 => \tx_state__0\(1),
      I2 => \tx_state__0\(2),
      I3 => baud_tick_16x,
      I4 => Q(0),
      I5 => Q(1),
      O => tx_i_5_n_0
    );
\tx_s_tick_cnt[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0808088008080888"
    )
        port map (
      I0 => \FSM_sequential_tx_state_reg[1]_0\,
      I1 => baud_tick_16x,
      I2 => \tx_state__0\(2),
      I3 => \tx_state__0\(0),
      I4 => \tx_state__0\(1),
      I5 => sr_out_wire(0),
      O => E(0)
    );
\tx_shift_reg[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0001000000000000"
    )
        port map (
      I0 => \tx_state__0\(2),
      I1 => \tx_state__0\(0),
      I2 => \tx_state__0\(1),
      I3 => sr_out_wire(0),
      I4 => baud_tick_16x,
      I5 => \FSM_sequential_tx_state_reg[1]_0\,
      O => \FSM_sequential_tx_state_reg[2]_0\(0)
    );
txe_flag_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7777333777773333"
    )
        port map (
      I0 => txe_flag_reg,
      I1 => \FSM_sequential_tx_state_reg[1]_0\,
      I2 => \tx_state__0\(2),
      I3 => txe_flag_reg_0,
      I4 => sr_out_wire(0),
      I5 => baud_tick_16x,
      O => \FSM_sequential_tx_state_reg[2]_1\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_UART_module is
  port (
    tx_out : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    clk : in STD_LOGIC;
    rst : in STD_LOGIC;
    \TDR_reg_reg[6]_0\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    \CR1_reg_reg[0]_0\ : in STD_LOGIC;
    \CR1_reg_reg[0]_1\ : in STD_LOGIC;
    \CR1_reg_reg[0]_2\ : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_UART_module;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_UART_module is
  signal BRR_reg : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal \CR1_reg[5]_i_2_n_0\ : STD_LOGIC;
  signal \CR1_reg_reg_n_0_[0]\ : STD_LOGIC;
  signal \CR1_reg_reg_n_0_[1]\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[0]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[1]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[2]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[2]_i_3_n_0\ : STD_LOGIC;
  signal M : STD_LOGIC;
  signal PCE : STD_LOGIC;
  signal PS : STD_LOGIC;
  signal TDR_reg : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal \TDR_reg[6]_i_1_n_0\ : STD_LOGIC;
  signal \TDR_reg[6]_i_2_n_0\ : STD_LOGIC;
  signal baud_gen_inst_n_0 : STD_LOGIC;
  signal baud_gen_inst_n_1 : STD_LOGIC;
  signal baud_gen_inst_n_2 : STD_LOGIC;
  signal baud_gen_inst_n_3 : STD_LOGIC;
  signal baud_gen_inst_n_4 : STD_LOGIC;
  signal baud_gen_inst_n_5 : STD_LOGIC;
  signal baud_gen_inst_n_6 : STD_LOGIC;
  signal baud_gen_inst_n_7 : STD_LOGIC;
  signal brr_en_wire : STD_LOGIC;
  signal cr_en_wire : STD_LOGIC;
  signal sr_out_wire : STD_LOGIC_VECTOR ( 0 to 0 );
  signal tx_bit_ptr : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \tx_bit_ptr[0]_i_1_n_0\ : STD_LOGIC;
  signal \tx_bit_ptr[1]_i_1_n_0\ : STD_LOGIC;
  signal \tx_bit_ptr[2]_i_1_n_0\ : STD_LOGIC;
  signal \tx_bit_ptr[3]_i_2_n_0\ : STD_LOGIC;
  signal \tx_bit_ptr[3]_i_4_n_0\ : STD_LOGIC;
  signal \tx_bit_ptr[3]_i_5_n_0\ : STD_LOGIC;
  signal tx_i_2_n_0 : STD_LOGIC;
  signal tx_i_3_n_0 : STD_LOGIC;
  signal tx_i_4_n_0 : STD_LOGIC;
  signal tx_i_6_n_0 : STD_LOGIC;
  signal tx_i_7_n_0 : STD_LOGIC;
  signal tx_i_8_n_0 : STD_LOGIC;
  signal tx_i_9_n_0 : STD_LOGIC;
  signal \^tx_out\ : STD_LOGIC;
  signal \tx_s_tick_cnt[0]_i_1_n_0\ : STD_LOGIC;
  signal \tx_s_tick_cnt[1]_i_1_n_0\ : STD_LOGIC;
  signal \tx_s_tick_cnt[2]_i_1_n_0\ : STD_LOGIC;
  signal \tx_s_tick_cnt[2]_i_2_n_0\ : STD_LOGIC;
  signal \tx_s_tick_cnt[3]_i_2_n_0\ : STD_LOGIC;
  signal \tx_s_tick_cnt[3]_i_3_n_0\ : STD_LOGIC;
  signal \tx_s_tick_cnt[3]_i_4_n_0\ : STD_LOGIC;
  signal \tx_s_tick_cnt_reg_n_0_[0]\ : STD_LOGIC;
  signal \tx_s_tick_cnt_reg_n_0_[1]\ : STD_LOGIC;
  signal \tx_s_tick_cnt_reg_n_0_[2]\ : STD_LOGIC;
  signal \tx_s_tick_cnt_reg_n_0_[3]\ : STD_LOGIC;
  signal tx_shift_reg : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal \tx_state__0\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal txe_flag_i_2_n_0 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CR1_reg[5]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \FSM_sequential_tx_state[0]_i_2\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \FSM_sequential_tx_state[2]_i_2\ : label is "soft_lutpair5";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_tx_state_reg[0]\ : label is "TX_IDLE:000,TX_START:001,TX_DATA:010,TX_STOP:100,TX_PARITY:011";
  attribute FSM_ENCODED_STATES of \FSM_sequential_tx_state_reg[1]\ : label is "TX_IDLE:000,TX_START:001,TX_DATA:010,TX_STOP:100,TX_PARITY:011";
  attribute FSM_ENCODED_STATES of \FSM_sequential_tx_state_reg[2]\ : label is "TX_IDLE:000,TX_START:001,TX_DATA:010,TX_STOP:100,TX_PARITY:011";
  attribute SOFT_HLUTNM of \tx_bit_ptr[0]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \tx_bit_ptr[1]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \tx_bit_ptr[2]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \tx_bit_ptr[3]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of tx_i_2 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of tx_i_6 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \tx_s_tick_cnt[0]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \tx_s_tick_cnt[2]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \tx_s_tick_cnt[3]_i_3\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \tx_s_tick_cnt[3]_i_4\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of txe_flag_i_2 : label is "soft_lutpair3";
begin
  tx_out <= \^tx_out\;
\BRR_reg[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => \TDR_reg[6]_i_2_n_0\,
      I1 => Q(3),
      I2 => Q(1),
      I3 => Q(2),
      O => brr_en_wire
    );
\BRR_reg_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => brr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(0),
      Q => BRR_reg(0)
    );
\BRR_reg_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => brr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(1),
      Q => BRR_reg(1)
    );
\BRR_reg_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => brr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(2),
      Q => BRR_reg(2)
    );
\BRR_reg_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => brr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(3),
      Q => BRR_reg(3)
    );
\BRR_reg_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => brr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(4),
      Q => BRR_reg(4)
    );
\BRR_reg_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => brr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(5),
      Q => BRR_reg(5)
    );
\BRR_reg_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => brr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(6),
      Q => BRR_reg(6)
    );
\CR1_reg[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00008000"
    )
        port map (
      I0 => \CR1_reg_reg[0]_0\,
      I1 => \CR1_reg_reg[0]_1\,
      I2 => \CR1_reg_reg[0]_2\,
      I3 => Q(0),
      I4 => \CR1_reg[5]_i_2_n_0\,
      O => cr_en_wire
    );
\CR1_reg[5]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"DF"
    )
        port map (
      I0 => Q(1),
      I1 => Q(2),
      I2 => Q(3),
      O => \CR1_reg[5]_i_2_n_0\
    );
\CR1_reg_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => cr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(0),
      Q => \CR1_reg_reg_n_0_[0]\
    );
\CR1_reg_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => cr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(1),
      Q => \CR1_reg_reg_n_0_[1]\
    );
\CR1_reg_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => cr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(3),
      Q => M
    );
\CR1_reg_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => cr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(4),
      Q => PCE
    );
\CR1_reg_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => cr_en_wire,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(5),
      Q => PS
    );
\FSM_sequential_tx_state[0]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \tx_state__0\(1),
      I1 => PCE,
      O => \FSM_sequential_tx_state[0]_i_2_n_0\
    );
\FSM_sequential_tx_state[1]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \CR1_reg_reg_n_0_[1]\,
      I1 => \CR1_reg_reg_n_0_[0]\,
      O => \FSM_sequential_tx_state[1]_i_2_n_0\
    );
\FSM_sequential_tx_state[2]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4F"
    )
        port map (
      I0 => \tx_state__0\(0),
      I1 => PCE,
      I2 => \tx_state__0\(1),
      O => \FSM_sequential_tx_state[2]_i_2_n_0\
    );
\FSM_sequential_tx_state[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFCECEFFFFCECE0"
    )
        port map (
      I0 => \tx_bit_ptr[3]_i_5_n_0\,
      I1 => \tx_bit_ptr[3]_i_4_n_0\,
      I2 => \tx_state__0\(1),
      I3 => \tx_state__0\(0),
      I4 => \tx_state__0\(2),
      I5 => sr_out_wire(0),
      O => \FSM_sequential_tx_state[2]_i_3_n_0\
    );
\FSM_sequential_tx_state_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => rst,
      D => baud_gen_inst_n_2,
      Q => \tx_state__0\(0)
    );
\FSM_sequential_tx_state_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => rst,
      D => baud_gen_inst_n_1,
      Q => \tx_state__0\(1)
    );
\FSM_sequential_tx_state_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => rst,
      D => baud_gen_inst_n_0,
      Q => \tx_state__0\(2)
    );
\TDR_reg[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2000000000000000"
    )
        port map (
      I0 => Q(1),
      I1 => Q(2),
      I2 => Q(3),
      I3 => \TDR_reg[6]_i_2_n_0\,
      I4 => \CR1_reg_reg_n_0_[0]\,
      I5 => \CR1_reg_reg_n_0_[1]\,
      O => \TDR_reg[6]_i_1_n_0\
    );
\TDR_reg[6]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => \CR1_reg_reg[0]_0\,
      I1 => \CR1_reg_reg[0]_1\,
      I2 => \CR1_reg_reg[0]_2\,
      I3 => Q(0),
      O => \TDR_reg[6]_i_2_n_0\
    );
\TDR_reg_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TDR_reg[6]_i_1_n_0\,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(0),
      Q => TDR_reg(0)
    );
\TDR_reg_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TDR_reg[6]_i_1_n_0\,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(1),
      Q => TDR_reg(1)
    );
\TDR_reg_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TDR_reg[6]_i_1_n_0\,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(2),
      Q => TDR_reg(2)
    );
\TDR_reg_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TDR_reg[6]_i_1_n_0\,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(3),
      Q => TDR_reg(3)
    );
\TDR_reg_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TDR_reg[6]_i_1_n_0\,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(4),
      Q => TDR_reg(4)
    );
\TDR_reg_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TDR_reg[6]_i_1_n_0\,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(5),
      Q => TDR_reg(5)
    );
\TDR_reg_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TDR_reg[6]_i_1_n_0\,
      CLR => rst,
      D => \TDR_reg_reg[6]_0\(6),
      Q => TDR_reg(6)
    );
baud_gen_inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_baud_rate_gen
     port map (
      \CR1_reg_reg[4]\ => baud_gen_inst_n_1,
      E(0) => baud_gen_inst_n_3,
      \FSM_sequential_tx_state_reg[0]\ => baud_gen_inst_n_7,
      \FSM_sequential_tx_state_reg[0]_0\ => \FSM_sequential_tx_state[0]_i_2_n_0\,
      \FSM_sequential_tx_state_reg[1]\(0) => baud_gen_inst_n_4,
      \FSM_sequential_tx_state_reg[1]_0\ => \FSM_sequential_tx_state[1]_i_2_n_0\,
      \FSM_sequential_tx_state_reg[2]\ => baud_gen_inst_n_2,
      \FSM_sequential_tx_state_reg[2]_0\(0) => baud_gen_inst_n_5,
      \FSM_sequential_tx_state_reg[2]_1\ => baud_gen_inst_n_6,
      \FSM_sequential_tx_state_reg[2]_2\ => \FSM_sequential_tx_state[2]_i_2_n_0\,
      \FSM_sequential_tx_state_reg[2]_3\ => \FSM_sequential_tx_state[2]_i_3_n_0\,
      Q(2) => PCE,
      Q(1) => \CR1_reg_reg_n_0_[1]\,
      Q(0) => \CR1_reg_reg_n_0_[0]\,
      baud_tick_reg_0 => baud_gen_inst_n_0,
      baud_tick_reg_1(6 downto 0) => BRR_reg(6 downto 0),
      clk => clk,
      rst => rst,
      sr_out_wire(0) => sr_out_wire(0),
      \tx_bit_ptr_reg[0]\ => \tx_bit_ptr[3]_i_4_n_0\,
      \tx_bit_ptr_reg[0]_0\ => \tx_bit_ptr[3]_i_5_n_0\,
      tx_out => \^tx_out\,
      tx_reg => tx_i_2_n_0,
      tx_reg_0 => tx_i_3_n_0,
      tx_reg_1 => tx_i_4_n_0,
      \tx_state__0\(2 downto 0) => \tx_state__0\(2 downto 0),
      txe_flag_reg => txe_flag_i_2_n_0,
      txe_flag_reg_0 => \tx_s_tick_cnt[2]_i_2_n_0\
    );
\tx_bit_ptr[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \tx_state__0\(1),
      I1 => tx_bit_ptr(0),
      O => \tx_bit_ptr[0]_i_1_n_0\
    );
\tx_bit_ptr[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => \tx_state__0\(1),
      I1 => tx_bit_ptr(1),
      I2 => tx_bit_ptr(0),
      O => \tx_bit_ptr[1]_i_1_n_0\
    );
\tx_bit_ptr[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6A00"
    )
        port map (
      I0 => tx_bit_ptr(2),
      I1 => tx_bit_ptr(1),
      I2 => tx_bit_ptr(0),
      I3 => \tx_state__0\(1),
      O => \tx_bit_ptr[2]_i_1_n_0\
    );
\tx_bit_ptr[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AAA8000"
    )
        port map (
      I0 => \tx_state__0\(1),
      I1 => tx_bit_ptr(2),
      I2 => tx_bit_ptr(1),
      I3 => tx_bit_ptr(0),
      I4 => tx_bit_ptr(3),
      O => \tx_bit_ptr[3]_i_2_n_0\
    );
\tx_bit_ptr[3]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \tx_s_tick_cnt_reg_n_0_[2]\,
      I1 => \tx_s_tick_cnt_reg_n_0_[0]\,
      I2 => \tx_s_tick_cnt_reg_n_0_[1]\,
      I3 => \tx_s_tick_cnt_reg_n_0_[3]\,
      O => \tx_bit_ptr[3]_i_4_n_0\
    );
\tx_bit_ptr[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5455555555555515"
    )
        port map (
      I0 => \tx_state__0\(0),
      I1 => M,
      I2 => tx_bit_ptr(3),
      I3 => tx_bit_ptr(0),
      I4 => tx_bit_ptr(1),
      I5 => tx_bit_ptr(2),
      O => \tx_bit_ptr[3]_i_5_n_0\
    );
\tx_bit_ptr_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_4,
      CLR => rst,
      D => \tx_bit_ptr[0]_i_1_n_0\,
      Q => tx_bit_ptr(0)
    );
\tx_bit_ptr_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_4,
      CLR => rst,
      D => \tx_bit_ptr[1]_i_1_n_0\,
      Q => tx_bit_ptr(1)
    );
\tx_bit_ptr_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_4,
      CLR => rst,
      D => \tx_bit_ptr[2]_i_1_n_0\,
      Q => tx_bit_ptr(2)
    );
\tx_bit_ptr_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_4,
      CLR => rst,
      D => \tx_bit_ptr[3]_i_2_n_0\,
      Q => tx_bit_ptr(3)
    );
tx_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \CR1_reg_reg_n_0_[0]\,
      I1 => \CR1_reg_reg_n_0_[1]\,
      I2 => \tx_state__0\(2),
      I3 => \tx_state__0\(1),
      O => tx_i_2_n_0
    );
tx_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAABAAABAAABAAAA"
    )
        port map (
      I0 => tx_i_6_n_0,
      I1 => tx_i_7_n_0,
      I2 => tx_bit_ptr(3),
      I3 => \tx_state__0\(0),
      I4 => tx_bit_ptr(2),
      I5 => tx_i_8_n_0,
      O => tx_i_3_n_0
    );
tx_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7DD7D77DD77D7DD7"
    )
        port map (
      I0 => \tx_state__0\(1),
      I1 => tx_i_9_n_0,
      I2 => tx_shift_reg(3),
      I3 => tx_shift_reg(2),
      I4 => tx_shift_reg(1),
      I5 => tx_shift_reg(0),
      O => tx_i_4_n_0
    );
tx_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"777F"
    )
        port map (
      I0 => \CR1_reg_reg_n_0_[0]\,
      I1 => \CR1_reg_reg_n_0_[1]\,
      I2 => \tx_state__0\(0),
      I3 => \tx_state__0\(1),
      O => tx_i_6_n_0
    );
tx_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0A002A2AAAA02A2"
    )
        port map (
      I0 => tx_bit_ptr(2),
      I1 => tx_shift_reg(4),
      I2 => tx_bit_ptr(0),
      I3 => tx_shift_reg(5),
      I4 => tx_bit_ptr(1),
      I5 => tx_shift_reg(6),
      O => tx_i_7_n_0
    );
tx_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => tx_shift_reg(3),
      I1 => tx_shift_reg(2),
      I2 => tx_bit_ptr(1),
      I3 => tx_shift_reg(1),
      I4 => tx_bit_ptr(0),
      I5 => tx_shift_reg(0),
      O => tx_i_8_n_0
    );
tx_i_9: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => tx_shift_reg(6),
      I1 => tx_shift_reg(5),
      I2 => tx_shift_reg(4),
      I3 => PS,
      O => tx_i_9_n_0
    );
tx_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => '1',
      D => baud_gen_inst_n_7,
      PRE => rst,
      Q => \^tx_out\
    );
\tx_s_tick_cnt[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0303033A"
    )
        port map (
      I0 => sr_out_wire(0),
      I1 => \tx_s_tick_cnt_reg_n_0_[0]\,
      I2 => \tx_state__0\(2),
      I3 => \tx_state__0\(0),
      I4 => \tx_state__0\(1),
      O => \tx_s_tick_cnt[0]_i_1_n_0\
    );
\tx_s_tick_cnt[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"003C003C003C3CAA"
    )
        port map (
      I0 => sr_out_wire(0),
      I1 => \tx_s_tick_cnt_reg_n_0_[0]\,
      I2 => \tx_s_tick_cnt_reg_n_0_[1]\,
      I3 => \tx_state__0\(2),
      I4 => \tx_state__0\(0),
      I5 => \tx_state__0\(1),
      O => \tx_s_tick_cnt[1]_i_1_n_0\
    );
\tx_s_tick_cnt[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00003CCC3CCCAAAA"
    )
        port map (
      I0 => sr_out_wire(0),
      I1 => \tx_s_tick_cnt_reg_n_0_[2]\,
      I2 => \tx_s_tick_cnt_reg_n_0_[1]\,
      I3 => \tx_s_tick_cnt_reg_n_0_[0]\,
      I4 => \tx_state__0\(2),
      I5 => \tx_s_tick_cnt[2]_i_2_n_0\,
      O => \tx_s_tick_cnt[2]_i_1_n_0\
    );
\tx_s_tick_cnt[2]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \tx_state__0\(1),
      I1 => \tx_state__0\(0),
      O => \tx_s_tick_cnt[2]_i_2_n_0\
    );
\tx_s_tick_cnt[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BEEEEEEEAAAAAAAA"
    )
        port map (
      I0 => \tx_s_tick_cnt[3]_i_3_n_0\,
      I1 => \tx_s_tick_cnt_reg_n_0_[3]\,
      I2 => \tx_s_tick_cnt_reg_n_0_[1]\,
      I3 => \tx_s_tick_cnt_reg_n_0_[0]\,
      I4 => \tx_s_tick_cnt_reg_n_0_[2]\,
      I5 => \tx_s_tick_cnt[3]_i_4_n_0\,
      O => \tx_s_tick_cnt[3]_i_2_n_0\
    );
\tx_s_tick_cnt[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0002"
    )
        port map (
      I0 => sr_out_wire(0),
      I1 => \tx_state__0\(1),
      I2 => \tx_state__0\(0),
      I3 => \tx_state__0\(2),
      O => \tx_s_tick_cnt[3]_i_3_n_0\
    );
\tx_s_tick_cnt[3]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"56"
    )
        port map (
      I0 => \tx_state__0\(2),
      I1 => \tx_state__0\(0),
      I2 => \tx_state__0\(1),
      O => \tx_s_tick_cnt[3]_i_4_n_0\
    );
\tx_s_tick_cnt_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_3,
      CLR => rst,
      D => \tx_s_tick_cnt[0]_i_1_n_0\,
      Q => \tx_s_tick_cnt_reg_n_0_[0]\
    );
\tx_s_tick_cnt_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_3,
      CLR => rst,
      D => \tx_s_tick_cnt[1]_i_1_n_0\,
      Q => \tx_s_tick_cnt_reg_n_0_[1]\
    );
\tx_s_tick_cnt_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_3,
      CLR => rst,
      D => \tx_s_tick_cnt[2]_i_1_n_0\,
      Q => \tx_s_tick_cnt_reg_n_0_[2]\
    );
\tx_s_tick_cnt_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_3,
      CLR => rst,
      D => \tx_s_tick_cnt[3]_i_2_n_0\,
      Q => \tx_s_tick_cnt_reg_n_0_[3]\
    );
\tx_shift_reg_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_5,
      CLR => rst,
      D => TDR_reg(0),
      Q => tx_shift_reg(0)
    );
\tx_shift_reg_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_5,
      CLR => rst,
      D => TDR_reg(1),
      Q => tx_shift_reg(1)
    );
\tx_shift_reg_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_5,
      CLR => rst,
      D => TDR_reg(2),
      Q => tx_shift_reg(2)
    );
\tx_shift_reg_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_5,
      CLR => rst,
      D => TDR_reg(3),
      Q => tx_shift_reg(3)
    );
\tx_shift_reg_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_5,
      CLR => rst,
      D => TDR_reg(4),
      Q => tx_shift_reg(4)
    );
\tx_shift_reg_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_5,
      CLR => rst,
      D => TDR_reg(5),
      Q => tx_shift_reg(5)
    );
\tx_shift_reg_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => baud_gen_inst_n_5,
      CLR => rst,
      D => TDR_reg(6),
      Q => tx_shift_reg(6)
    );
txe_flag_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => \TDR_reg[6]_i_2_n_0\,
      I1 => Q(3),
      I2 => Q(2),
      I3 => Q(1),
      O => txe_flag_i_2_n_0
    );
txe_flag_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => '1',
      D => baud_gen_inst_n_6,
      PRE => rst,
      Q => sr_out_wire(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_uart_top is
  port (
    tx_out : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    clk : in STD_LOGIC;
    rst : in STD_LOGIC;
    \TDR_reg_reg[6]\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    \CR1_reg_reg[0]\ : in STD_LOGIC;
    \CR1_reg_reg[0]_0\ : in STD_LOGIC;
    \CR1_reg_reg[0]_1\ : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_uart_top;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_uart_top is
begin
core_uart: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_UART_module
     port map (
      \CR1_reg_reg[0]_0\ => \CR1_reg_reg[0]\,
      \CR1_reg_reg[0]_1\ => \CR1_reg_reg[0]_0\,
      \CR1_reg_reg[0]_2\ => \CR1_reg_reg[0]_1\,
      Q(3 downto 0) => Q(3 downto 0),
      \TDR_reg_reg[6]_0\(6 downto 0) => \TDR_reg_reg[6]\(6 downto 0),
      clk => clk,
      rst => rst,
      tx_out => tx_out
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_apb_interface is
  port (
    penable_reg_0 : out STD_LOGIC;
    \psel_reg[1]_0\ : out STD_LOGIC;
    E : out STD_LOGIC_VECTOR ( 0 to 0 );
    state : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \FSM_onehot_state_reg[6]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_onehot_state_reg[1]\ : out STD_LOGIC;
    tx_out : out STD_LOGIC;
    rst : in STD_LOGIC;
    clk : in STD_LOGIC;
    pwrite_reg_0 : in STD_LOGIC;
    penable_reg_1 : in STD_LOGIC;
    \delay_cnt_reg[0]\ : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    cpu_write_reg : in STD_LOGIC_VECTOR ( 0 to 0 );
    \paddr_reg[6]_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \pwdata_reg[6]_0\ : in STD_LOGIC_VECTOR ( 6 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_apb_interface;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_apb_interface is
  signal \FSM_sequential_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_2_n_0\ : STD_LOGIC;
  signal apb_done : STD_LOGIC;
  signal cpu_write : STD_LOGIC;
  signal \paddr[6]_i_1_n_0\ : STD_LOGIC;
  signal \paddr_reg_n_0_[2]\ : STD_LOGIC;
  signal \paddr_reg_n_0_[3]\ : STD_LOGIC;
  signal \paddr_reg_n_0_[4]\ : STD_LOGIC;
  signal \paddr_reg_n_0_[6]\ : STD_LOGIC;
  signal \^penable_reg_0\ : STD_LOGIC;
  signal \psel[1]_i_1_n_0\ : STD_LOGIC;
  signal \^psel_reg[1]_0\ : STD_LOGIC;
  signal \pwdata_reg_n_0_[0]\ : STD_LOGIC;
  signal \pwdata_reg_n_0_[1]\ : STD_LOGIC;
  signal \pwdata_reg_n_0_[2]\ : STD_LOGIC;
  signal \pwdata_reg_n_0_[3]\ : STD_LOGIC;
  signal \pwdata_reg_n_0_[4]\ : STD_LOGIC;
  signal \pwdata_reg_n_0_[5]\ : STD_LOGIC;
  signal \pwdata_reg_n_0_[6]\ : STD_LOGIC;
  signal pwrite_reg_n_0 : STD_LOGIC;
  signal \^state\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal txn_done_r : STD_LOGIC;
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[0]\ : label is "READ:10,WRITE:01,IDLE:00,WAIT:11";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[1]\ : label is "READ:10,WRITE:01,IDLE:00,WAIT:11";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \delay_cnt[15]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of txn_done_r_i_1 : label is "soft_lutpair7";
begin
  penable_reg_0 <= \^penable_reg_0\;
  \psel_reg[1]_0\ <= \^psel_reg[1]_0\;
  state(1 downto 0) <= \^state\(1 downto 0);
\FSM_onehot_state[7]_inv_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => cpu_write,
      I1 => Q(3),
      I2 => \delay_cnt_reg[0]\,
      O => \FSM_onehot_state_reg[6]\(0)
    );
\FSM_onehot_state[7]_inv_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEAAAAAAAAAAAA"
    )
        port map (
      I0 => cpu_write_reg(0),
      I1 => Q(0),
      I2 => Q(2),
      I3 => Q(1),
      I4 => \^state\(0),
      I5 => \^state\(1),
      O => cpu_write
    );
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCEC33330020"
    )
        port map (
      I0 => pwrite_reg_0,
      I1 => \^state\(1),
      I2 => \paddr_reg[6]_0\(3),
      I3 => txn_done_r,
      I4 => \^state\(0),
      I5 => \FSM_sequential_state[1]_i_2_n_0\,
      O => \FSM_sequential_state[0]_i_1_n_0\
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCDC0000CCDC"
    )
        port map (
      I0 => pwrite_reg_0,
      I1 => \^state\(1),
      I2 => \paddr_reg[6]_0\(3),
      I3 => txn_done_r,
      I4 => \^state\(0),
      I5 => \FSM_sequential_state[1]_i_2_n_0\,
      O => \FSM_sequential_state[1]_i_1_n_0\
    );
\FSM_sequential_state[1]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^penable_reg_0\,
      I1 => \^psel_reg[1]_0\,
      O => \FSM_sequential_state[1]_i_2_n_0\
    );
\FSM_sequential_state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \FSM_sequential_state[0]_i_1_n_0\,
      Q => \^state\(0),
      R => rst
    );
\FSM_sequential_state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \FSM_sequential_state[1]_i_1_n_0\,
      Q => \^state\(1),
      R => rst
    );
cpu_write_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAABFFFFAAAAAAAA"
    )
        port map (
      I0 => cpu_write_reg(0),
      I1 => Q(0),
      I2 => Q(2),
      I3 => Q(1),
      I4 => apb_done,
      I5 => pwrite_reg_0,
      O => \FSM_onehot_state_reg[1]\
    );
\delay_cnt[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F4444444"
    )
        port map (
      I0 => \delay_cnt_reg[0]\,
      I1 => Q(3),
      I2 => Q(2),
      I3 => \^state\(0),
      I4 => \^state\(1),
      O => E(0)
    );
\paddr[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => txn_done_r,
      I1 => \paddr_reg[6]_0\(3),
      I2 => \^state\(0),
      I3 => \^state\(1),
      O => \paddr[6]_i_1_n_0\
    );
\paddr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \paddr_reg[6]_0\(0),
      Q => \paddr_reg_n_0_[2]\,
      R => rst
    );
\paddr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \paddr_reg[6]_0\(1),
      Q => \paddr_reg_n_0_[3]\,
      R => rst
    );
\paddr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \paddr_reg[6]_0\(2),
      Q => \paddr_reg_n_0_[4]\,
      R => rst
    );
\paddr_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \paddr_reg[6]_0\(3),
      Q => \paddr_reg_n_0_[6]\,
      R => rst
    );
penable_reg: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => penable_reg_1,
      Q => \^penable_reg_0\,
      R => rst
    );
\psel[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F000FF000202F202"
    )
        port map (
      I0 => \paddr_reg[6]_0\(3),
      I1 => txn_done_r,
      I2 => \^state\(1),
      I3 => \^psel_reg[1]_0\,
      I4 => \^penable_reg_0\,
      I5 => \^state\(0),
      O => \psel[1]_i_1_n_0\
    );
\psel_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \psel[1]_i_1_n_0\,
      Q => \^psel_reg[1]_0\,
      R => rst
    );
\pwdata_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \pwdata_reg[6]_0\(0),
      Q => \pwdata_reg_n_0_[0]\,
      R => rst
    );
\pwdata_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \pwdata_reg[6]_0\(1),
      Q => \pwdata_reg_n_0_[1]\,
      R => rst
    );
\pwdata_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \pwdata_reg[6]_0\(2),
      Q => \pwdata_reg_n_0_[2]\,
      R => rst
    );
\pwdata_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \pwdata_reg[6]_0\(3),
      Q => \pwdata_reg_n_0_[3]\,
      R => rst
    );
\pwdata_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \pwdata_reg[6]_0\(4),
      Q => \pwdata_reg_n_0_[4]\,
      R => rst
    );
\pwdata_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \pwdata_reg[6]_0\(5),
      Q => \pwdata_reg_n_0_[5]\,
      R => rst
    );
\pwdata_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => \pwdata_reg[6]_0\(6),
      Q => \pwdata_reg_n_0_[6]\,
      R => rst
    );
pwrite_reg: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \paddr[6]_i_1_n_0\,
      D => pwrite_reg_0,
      Q => pwrite_reg_n_0,
      R => rst
    );
txn_done_r_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^state\(0),
      I1 => \^state\(1),
      O => apb_done
    );
txn_done_r_reg: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => apb_done,
      Q => txn_done_r,
      R => rst
    );
uart_u: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_uart_top
     port map (
      \CR1_reg_reg[0]\ => \^penable_reg_0\,
      \CR1_reg_reg[0]_0\ => \^psel_reg[1]_0\,
      \CR1_reg_reg[0]_1\ => pwrite_reg_n_0,
      Q(3) => \paddr_reg_n_0_[6]\,
      Q(2) => \paddr_reg_n_0_[4]\,
      Q(1) => \paddr_reg_n_0_[3]\,
      Q(0) => \paddr_reg_n_0_[2]\,
      \TDR_reg_reg[6]\(6) => \pwdata_reg_n_0_[6]\,
      \TDR_reg_reg[6]\(5) => \pwdata_reg_n_0_[5]\,
      \TDR_reg_reg[6]\(4) => \pwdata_reg_n_0_[4]\,
      \TDR_reg_reg[6]\(3) => \pwdata_reg_n_0_[3]\,
      \TDR_reg_reg[6]\(2) => \pwdata_reg_n_0_[2]\,
      \TDR_reg_reg[6]\(1) => \pwdata_reg_n_0_[1]\,
      \TDR_reg_reg[6]\(0) => \pwdata_reg_n_0_[0]\,
      clk => clk,
      rst => rst,
      tx_out => tx_out
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_hw_apb_uart_tb is
  port (
    tx_out : out STD_LOGIC;
    tx_busy_led : out STD_LOGIC;
    clk : in STD_LOGIC;
    rst : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_hw_apb_uart_tb;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_hw_apb_uart_tb is
  signal \FSM_onehot_state[4]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[4]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[7]_inv_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[7]_inv_i_4_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[7]_inv_i_5_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[7]_inv_i_6_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[7]_inv_i_7_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[7]_inv_i_8_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[7]_inv_i_9_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[0]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[1]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[2]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[3]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[4]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[5]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[6]\ : STD_LOGIC;
  signal char_idx : STD_LOGIC;
  signal \char_idx[0]_i_1_n_0\ : STD_LOGIC;
  signal \char_idx[3]_i_1_n_0\ : STD_LOGIC;
  signal char_idx_reg : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal cpu_paddr : STD_LOGIC_VECTOR ( 13 downto 3 );
  signal \cpu_paddr_reg_n_0_[13]\ : STD_LOGIC;
  signal \cpu_paddr_reg_n_0_[2]\ : STD_LOGIC;
  signal \cpu_paddr_reg_n_0_[3]\ : STD_LOGIC;
  signal \cpu_paddr_reg_n_0_[4]\ : STD_LOGIC;
  signal \cpu_wdata[0]_i_1_n_0\ : STD_LOGIC;
  signal \cpu_wdata[1]_i_1_n_0\ : STD_LOGIC;
  signal \cpu_wdata[1]_i_2_n_0\ : STD_LOGIC;
  signal \cpu_wdata[2]_i_1_n_0\ : STD_LOGIC;
  signal \cpu_wdata[3]_i_1_n_0\ : STD_LOGIC;
  signal \cpu_wdata[3]_i_2_n_0\ : STD_LOGIC;
  signal \cpu_wdata[4]_i_1_n_0\ : STD_LOGIC;
  signal \cpu_wdata[4]_i_2_n_0\ : STD_LOGIC;
  signal \cpu_wdata[5]_i_1_n_0\ : STD_LOGIC;
  signal \cpu_wdata[6]_i_1_n_0\ : STD_LOGIC;
  signal \cpu_wdata[6]_i_2_n_0\ : STD_LOGIC;
  signal \cpu_wdata[6]_i_3_n_0\ : STD_LOGIC;
  signal \cpu_wdata_reg_n_0_[0]\ : STD_LOGIC;
  signal \cpu_wdata_reg_n_0_[1]\ : STD_LOGIC;
  signal \cpu_wdata_reg_n_0_[2]\ : STD_LOGIC;
  signal \cpu_wdata_reg_n_0_[3]\ : STD_LOGIC;
  signal \cpu_wdata_reg_n_0_[4]\ : STD_LOGIC;
  signal \cpu_wdata_reg_n_0_[5]\ : STD_LOGIC;
  signal \cpu_wdata_reg_n_0_[6]\ : STD_LOGIC;
  signal cpu_write_reg_n_0 : STD_LOGIC;
  signal delay_cnt : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \delay_cnt0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__0_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__0_n_1\ : STD_LOGIC;
  signal \delay_cnt0_carry__0_n_2\ : STD_LOGIC;
  signal \delay_cnt0_carry__0_n_3\ : STD_LOGIC;
  signal \delay_cnt0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__1_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__1_n_1\ : STD_LOGIC;
  signal \delay_cnt0_carry__1_n_2\ : STD_LOGIC;
  signal \delay_cnt0_carry__1_n_3\ : STD_LOGIC;
  signal \delay_cnt0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \delay_cnt0_carry__2_n_2\ : STD_LOGIC;
  signal \delay_cnt0_carry__2_n_3\ : STD_LOGIC;
  signal delay_cnt0_carry_i_1_n_0 : STD_LOGIC;
  signal delay_cnt0_carry_i_2_n_0 : STD_LOGIC;
  signal delay_cnt0_carry_i_3_n_0 : STD_LOGIC;
  signal delay_cnt0_carry_i_4_n_0 : STD_LOGIC;
  signal delay_cnt0_carry_n_0 : STD_LOGIC;
  signal delay_cnt0_carry_n_1 : STD_LOGIC;
  signal delay_cnt0_carry_n_2 : STD_LOGIC;
  signal delay_cnt0_carry_n_3 : STD_LOGIC;
  signal \delay_cnt[0]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[10]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[11]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[12]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[13]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[14]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[15]_i_2_n_0\ : STD_LOGIC;
  signal \delay_cnt[1]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[2]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[3]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[4]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[5]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[6]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[7]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[8]_i_1_n_0\ : STD_LOGIC;
  signal \delay_cnt[9]_i_1_n_0\ : STD_LOGIC;
  signal delay_cnt_0 : STD_LOGIC;
  signal dut_n_0 : STD_LOGIC;
  signal dut_n_1 : STD_LOGIC;
  signal dut_n_5 : STD_LOGIC;
  signal dut_n_6 : STD_LOGIC;
  signal in5 : STD_LOGIC_VECTOR ( 15 downto 1 );
  signal p_0_in : STD_LOGIC_VECTOR ( 5 downto 1 );
  signal penable_i_1_n_0 : STD_LOGIC;
  signal state : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_delay_cnt0_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_delay_cnt0_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_onehot_state[7]_inv_i_5\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \FSM_onehot_state[7]_inv_i_8\ : label is "soft_lutpair11";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[3]\ : label is "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[4]\ : label is "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[5]\ : label is "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[6]\ : label is "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[7]_inv\ : label is "CFG_BRR:00000001,WAIT_BRR:00000010,CFG_CR1:00000100,WAIT_CR1:00001000,WAIT_APB:00100000,WAIT_TX:01000000,SEND_CHAR:00010000,DONE:10000000";
  attribute inverted : string;
  attribute inverted of \FSM_onehot_state_reg[7]_inv\ : label is "yes";
  attribute SOFT_HLUTNM of \char_idx[1]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \char_idx[2]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \char_idx[3]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \char_idx[4]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \cpu_wdata[0]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \cpu_wdata[1]_i_2\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \cpu_wdata[3]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \cpu_wdata[4]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \cpu_wdata[5]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cpu_wdata[6]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cpu_wdata[6]_i_3\ : label is "soft_lutpair8";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of delay_cnt0_carry : label is 35;
  attribute ADDER_THRESHOLD of \delay_cnt0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \delay_cnt0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \delay_cnt0_carry__2\ : label is 35;
  attribute SOFT_HLUTNM of \delay_cnt[0]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \delay_cnt[10]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \delay_cnt[11]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \delay_cnt[12]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \delay_cnt[13]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \delay_cnt[14]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \delay_cnt[15]_i_2\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \delay_cnt[2]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \delay_cnt[3]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \delay_cnt[4]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \delay_cnt[5]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \delay_cnt[6]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \delay_cnt[7]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \delay_cnt[8]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \delay_cnt[9]_i_1\ : label is "soft_lutpair15";
begin
\FSM_onehot_state[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[3]\,
      I1 => \FSM_onehot_state[4]_i_2_n_0\,
      I2 => \FSM_onehot_state_reg_n_0_[6]\,
      O => \FSM_onehot_state[4]_i_1_n_0\
    );
\FSM_onehot_state[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => char_idx_reg(4),
      I1 => char_idx_reg(3),
      I2 => char_idx_reg(2),
      I3 => char_idx_reg(5),
      I4 => char_idx_reg(0),
      I5 => char_idx_reg(1),
      O => \FSM_onehot_state[4]_i_2_n_0\
    );
\FSM_onehot_state[7]_inv_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFFFFFFFFFFFFFFF"
    )
        port map (
      I0 => char_idx_reg(1),
      I1 => char_idx_reg(0),
      I2 => char_idx_reg(5),
      I3 => char_idx_reg(2),
      I4 => \FSM_onehot_state[7]_inv_i_5_n_0\,
      I5 => \FSM_onehot_state_reg_n_0_[6]\,
      O => \FSM_onehot_state[7]_inv_i_2_n_0\
    );
\FSM_onehot_state[7]_inv_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => \FSM_onehot_state[7]_inv_i_6_n_0\,
      I1 => \FSM_onehot_state[7]_inv_i_7_n_0\,
      I2 => \FSM_onehot_state[7]_inv_i_8_n_0\,
      I3 => \FSM_onehot_state[7]_inv_i_9_n_0\,
      O => \FSM_onehot_state[7]_inv_i_4_n_0\
    );
\FSM_onehot_state[7]_inv_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => char_idx_reg(3),
      I1 => char_idx_reg(4),
      O => \FSM_onehot_state[7]_inv_i_5_n_0\
    );
\FSM_onehot_state[7]_inv_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => delay_cnt(4),
      I1 => delay_cnt(3),
      I2 => delay_cnt(2),
      I3 => delay_cnt(5),
      O => \FSM_onehot_state[7]_inv_i_6_n_0\
    );
\FSM_onehot_state[7]_inv_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => delay_cnt(13),
      I1 => delay_cnt(10),
      I2 => delay_cnt(8),
      I3 => delay_cnt(9),
      O => \FSM_onehot_state[7]_inv_i_7_n_0\
    );
\FSM_onehot_state[7]_inv_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => delay_cnt(12),
      I1 => delay_cnt(14),
      I2 => delay_cnt(0),
      I3 => delay_cnt(11),
      O => \FSM_onehot_state[7]_inv_i_8_n_0\
    );
\FSM_onehot_state[7]_inv_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => delay_cnt(15),
      I1 => delay_cnt(1),
      I2 => delay_cnt(7),
      I3 => delay_cnt(6),
      O => \FSM_onehot_state[7]_inv_i_9_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => clk,
      CE => dut_n_5,
      D => '0',
      Q => \FSM_onehot_state_reg_n_0_[0]\,
      S => rst
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => dut_n_5,
      D => \FSM_onehot_state_reg_n_0_[0]\,
      Q => \FSM_onehot_state_reg_n_0_[1]\,
      R => rst
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => dut_n_5,
      D => \FSM_onehot_state_reg_n_0_[1]\,
      Q => \FSM_onehot_state_reg_n_0_[2]\,
      R => rst
    );
\FSM_onehot_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => dut_n_5,
      D => \FSM_onehot_state_reg_n_0_[2]\,
      Q => \FSM_onehot_state_reg_n_0_[3]\,
      R => rst
    );
\FSM_onehot_state_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => dut_n_5,
      D => \FSM_onehot_state[4]_i_1_n_0\,
      Q => \FSM_onehot_state_reg_n_0_[4]\,
      R => rst
    );
\FSM_onehot_state_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => dut_n_5,
      D => \FSM_onehot_state_reg_n_0_[4]\,
      Q => \FSM_onehot_state_reg_n_0_[5]\,
      R => rst
    );
\FSM_onehot_state_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => dut_n_5,
      D => \FSM_onehot_state_reg_n_0_[5]\,
      Q => \FSM_onehot_state_reg_n_0_[6]\,
      R => rst
    );
\FSM_onehot_state_reg[7]_inv\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => clk,
      CE => dut_n_5,
      D => \FSM_onehot_state[7]_inv_i_2_n_0\,
      Q => tx_busy_led,
      S => rst
    );
\char_idx[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => char_idx_reg(0),
      O => \char_idx[0]_i_1_n_0\
    );
\char_idx[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => char_idx_reg(1),
      I1 => char_idx_reg(0),
      O => p_0_in(1)
    );
\char_idx[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => char_idx_reg(2),
      I1 => char_idx_reg(1),
      I2 => char_idx_reg(0),
      O => p_0_in(2)
    );
\char_idx[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => char_idx_reg(3),
      I1 => char_idx_reg(2),
      I2 => char_idx_reg(0),
      I3 => char_idx_reg(1),
      O => \char_idx[3]_i_1_n_0\
    );
\char_idx[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => char_idx_reg(4),
      I1 => char_idx_reg(3),
      I2 => char_idx_reg(1),
      I3 => char_idx_reg(0),
      I4 => char_idx_reg(2),
      O => p_0_in(4)
    );
\char_idx[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"20"
    )
        port map (
      I0 => \FSM_onehot_state[7]_inv_i_4_n_0\,
      I1 => \FSM_onehot_state[4]_i_2_n_0\,
      I2 => \FSM_onehot_state_reg_n_0_[6]\,
      O => char_idx
    );
\char_idx[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => char_idx_reg(5),
      I1 => char_idx_reg(1),
      I2 => char_idx_reg(0),
      I3 => char_idx_reg(2),
      I4 => char_idx_reg(3),
      I5 => char_idx_reg(4),
      O => p_0_in(5)
    );
\char_idx_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => char_idx,
      D => \char_idx[0]_i_1_n_0\,
      Q => char_idx_reg(0),
      R => rst
    );
\char_idx_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => char_idx,
      D => p_0_in(1),
      Q => char_idx_reg(1),
      R => rst
    );
\char_idx_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => char_idx,
      D => p_0_in(2),
      Q => char_idx_reg(2),
      R => rst
    );
\char_idx_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => char_idx,
      D => \char_idx[3]_i_1_n_0\,
      Q => char_idx_reg(3),
      R => rst
    );
\char_idx_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => char_idx,
      D => p_0_in(4),
      Q => char_idx_reg(4),
      R => rst
    );
\char_idx_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => char_idx,
      D => p_0_in(5),
      Q => char_idx_reg(5),
      R => rst
    );
\cpu_paddr[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[4]\,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      I2 => \FSM_onehot_state_reg_n_0_[0]\,
      O => cpu_paddr(13)
    );
\cpu_paddr[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[4]\,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      O => cpu_paddr(3)
    );
\cpu_paddr_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => cpu_paddr(13),
      Q => \cpu_paddr_reg_n_0_[13]\,
      R => rst
    );
\cpu_paddr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \FSM_onehot_state_reg_n_0_[2]\,
      Q => \cpu_paddr_reg_n_0_[2]\,
      R => rst
    );
\cpu_paddr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => cpu_paddr(3),
      Q => \cpu_paddr_reg_n_0_[3]\,
      R => rst
    );
\cpu_paddr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \FSM_onehot_state_reg_n_0_[0]\,
      Q => \cpu_paddr_reg_n_0_[4]\,
      R => rst
    );
\cpu_wdata[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FEEFEEEE"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[2]\,
      I1 => \FSM_onehot_state_reg_n_0_[0]\,
      I2 => char_idx_reg(0),
      I3 => \cpu_wdata[6]_i_2_n_0\,
      I4 => \FSM_onehot_state_reg_n_0_[4]\,
      O => \cpu_wdata[0]_i_1_n_0\
    );
\cpu_wdata[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABFEEEBBAAAAAAAA"
    )
        port map (
      I0 => \cpu_wdata[1]_i_2_n_0\,
      I1 => \cpu_wdata[6]_i_3_n_0\,
      I2 => \cpu_wdata[6]_i_2_n_0\,
      I3 => char_idx_reg(1),
      I4 => char_idx_reg(0),
      I5 => \FSM_onehot_state_reg_n_0_[4]\,
      O => \cpu_wdata[1]_i_1_n_0\
    );
\cpu_wdata[1]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[0]\,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \cpu_wdata[1]_i_2_n_0\
    );
\cpu_wdata[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2A80A00A2A80A802"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[4]\,
      I1 => char_idx_reg(0),
      I2 => char_idx_reg(1),
      I3 => char_idx_reg(2),
      I4 => \cpu_wdata[6]_i_3_n_0\,
      I5 => \cpu_wdata[6]_i_2_n_0\,
      O => \cpu_wdata[2]_i_1_n_0\
    );
\cpu_wdata[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[0]\,
      I1 => \cpu_wdata[3]_i_2_n_0\,
      I2 => \FSM_onehot_state_reg_n_0_[4]\,
      O => \cpu_wdata[3]_i_1_n_0\
    );
\cpu_wdata[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A942BD42A902FD08"
    )
        port map (
      I0 => char_idx_reg(5),
      I1 => char_idx_reg(1),
      I2 => char_idx_reg(2),
      I3 => char_idx_reg(3),
      I4 => char_idx_reg(4),
      I5 => char_idx_reg(0),
      O => \cpu_wdata[3]_i_2_n_0\
    );
\cpu_wdata[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[0]\,
      I1 => \cpu_wdata[4]_i_2_n_0\,
      I2 => \FSM_onehot_state_reg_n_0_[4]\,
      O => \cpu_wdata[4]_i_1_n_0\
    );
\cpu_wdata[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0002BFFD0002FFF5"
    )
        port map (
      I0 => char_idx_reg(5),
      I1 => char_idx_reg(1),
      I2 => char_idx_reg(2),
      I3 => char_idx_reg(3),
      I4 => char_idx_reg(4),
      I5 => char_idx_reg(0),
      O => \cpu_wdata[4]_i_2_n_0\
    );
\cpu_wdata[5]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[4]\,
      I1 => \cpu_wdata[6]_i_2_n_0\,
      O => \cpu_wdata[5]_i_1_n_0\
    );
\cpu_wdata[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[4]\,
      I1 => \cpu_wdata[6]_i_2_n_0\,
      I2 => \cpu_wdata[6]_i_3_n_0\,
      O => \cpu_wdata[6]_i_1_n_0\
    );
\cpu_wdata[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAA8AAA8AAA8"
    )
        port map (
      I0 => char_idx_reg(5),
      I1 => char_idx_reg(3),
      I2 => char_idx_reg(4),
      I3 => char_idx_reg(2),
      I4 => char_idx_reg(1),
      I5 => char_idx_reg(0),
      O => \cpu_wdata[6]_i_2_n_0\
    );
\cpu_wdata[6]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01555555"
    )
        port map (
      I0 => char_idx_reg(5),
      I1 => char_idx_reg(1),
      I2 => char_idx_reg(2),
      I3 => char_idx_reg(3),
      I4 => char_idx_reg(4),
      O => \cpu_wdata[6]_i_3_n_0\
    );
\cpu_wdata_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => cpu_paddr(13),
      D => \cpu_wdata[0]_i_1_n_0\,
      Q => \cpu_wdata_reg_n_0_[0]\,
      R => rst
    );
\cpu_wdata_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => cpu_paddr(13),
      D => \cpu_wdata[1]_i_1_n_0\,
      Q => \cpu_wdata_reg_n_0_[1]\,
      R => rst
    );
\cpu_wdata_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => cpu_paddr(13),
      D => \cpu_wdata[2]_i_1_n_0\,
      Q => \cpu_wdata_reg_n_0_[2]\,
      R => rst
    );
\cpu_wdata_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => cpu_paddr(13),
      D => \cpu_wdata[3]_i_1_n_0\,
      Q => \cpu_wdata_reg_n_0_[3]\,
      R => rst
    );
\cpu_wdata_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => cpu_paddr(13),
      D => \cpu_wdata[4]_i_1_n_0\,
      Q => \cpu_wdata_reg_n_0_[4]\,
      R => rst
    );
\cpu_wdata_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => cpu_paddr(13),
      D => \cpu_wdata[5]_i_1_n_0\,
      Q => \cpu_wdata_reg_n_0_[5]\,
      R => rst
    );
\cpu_wdata_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => cpu_paddr(13),
      D => \cpu_wdata[6]_i_1_n_0\,
      Q => \cpu_wdata_reg_n_0_[6]\,
      R => rst
    );
cpu_write_reg: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => dut_n_6,
      Q => cpu_write_reg_n_0,
      R => rst
    );
delay_cnt0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => delay_cnt0_carry_n_0,
      CO(2) => delay_cnt0_carry_n_1,
      CO(1) => delay_cnt0_carry_n_2,
      CO(0) => delay_cnt0_carry_n_3,
      CYINIT => delay_cnt(0),
      DI(3 downto 0) => delay_cnt(4 downto 1),
      O(3 downto 0) => in5(4 downto 1),
      S(3) => delay_cnt0_carry_i_1_n_0,
      S(2) => delay_cnt0_carry_i_2_n_0,
      S(1) => delay_cnt0_carry_i_3_n_0,
      S(0) => delay_cnt0_carry_i_4_n_0
    );
\delay_cnt0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => delay_cnt0_carry_n_0,
      CO(3) => \delay_cnt0_carry__0_n_0\,
      CO(2) => \delay_cnt0_carry__0_n_1\,
      CO(1) => \delay_cnt0_carry__0_n_2\,
      CO(0) => \delay_cnt0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => delay_cnt(8 downto 5),
      O(3 downto 0) => in5(8 downto 5),
      S(3) => \delay_cnt0_carry__0_i_1_n_0\,
      S(2) => \delay_cnt0_carry__0_i_2_n_0\,
      S(1) => \delay_cnt0_carry__0_i_3_n_0\,
      S(0) => \delay_cnt0_carry__0_i_4_n_0\
    );
\delay_cnt0_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(8),
      O => \delay_cnt0_carry__0_i_1_n_0\
    );
\delay_cnt0_carry__0_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(7),
      O => \delay_cnt0_carry__0_i_2_n_0\
    );
\delay_cnt0_carry__0_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(6),
      O => \delay_cnt0_carry__0_i_3_n_0\
    );
\delay_cnt0_carry__0_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(5),
      O => \delay_cnt0_carry__0_i_4_n_0\
    );
\delay_cnt0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \delay_cnt0_carry__0_n_0\,
      CO(3) => \delay_cnt0_carry__1_n_0\,
      CO(2) => \delay_cnt0_carry__1_n_1\,
      CO(1) => \delay_cnt0_carry__1_n_2\,
      CO(0) => \delay_cnt0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => delay_cnt(12 downto 9),
      O(3 downto 0) => in5(12 downto 9),
      S(3) => \delay_cnt0_carry__1_i_1_n_0\,
      S(2) => \delay_cnt0_carry__1_i_2_n_0\,
      S(1) => \delay_cnt0_carry__1_i_3_n_0\,
      S(0) => \delay_cnt0_carry__1_i_4_n_0\
    );
\delay_cnt0_carry__1_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(12),
      O => \delay_cnt0_carry__1_i_1_n_0\
    );
\delay_cnt0_carry__1_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(11),
      O => \delay_cnt0_carry__1_i_2_n_0\
    );
\delay_cnt0_carry__1_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(10),
      O => \delay_cnt0_carry__1_i_3_n_0\
    );
\delay_cnt0_carry__1_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(9),
      O => \delay_cnt0_carry__1_i_4_n_0\
    );
\delay_cnt0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \delay_cnt0_carry__1_n_0\,
      CO(3 downto 2) => \NLW_delay_cnt0_carry__2_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \delay_cnt0_carry__2_n_2\,
      CO(0) => \delay_cnt0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => delay_cnt(14 downto 13),
      O(3) => \NLW_delay_cnt0_carry__2_O_UNCONNECTED\(3),
      O(2 downto 0) => in5(15 downto 13),
      S(3) => '0',
      S(2) => \delay_cnt0_carry__2_i_1_n_0\,
      S(1) => \delay_cnt0_carry__2_i_2_n_0\,
      S(0) => \delay_cnt0_carry__2_i_3_n_0\
    );
\delay_cnt0_carry__2_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(15),
      O => \delay_cnt0_carry__2_i_1_n_0\
    );
\delay_cnt0_carry__2_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(14),
      O => \delay_cnt0_carry__2_i_2_n_0\
    );
\delay_cnt0_carry__2_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(13),
      O => \delay_cnt0_carry__2_i_3_n_0\
    );
delay_cnt0_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(4),
      O => delay_cnt0_carry_i_1_n_0
    );
delay_cnt0_carry_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(3),
      O => delay_cnt0_carry_i_2_n_0
    );
delay_cnt0_carry_i_3: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(2),
      O => delay_cnt0_carry_i_3_n_0
    );
delay_cnt0_carry_i_4: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => delay_cnt(1),
      O => delay_cnt0_carry_i_4_n_0
    );
\delay_cnt[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => delay_cnt(0),
      O => \delay_cnt[0]_i_1_n_0\
    );
\delay_cnt[10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(10),
      O => \delay_cnt[10]_i_1_n_0\
    );
\delay_cnt[11]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(11),
      O => \delay_cnt[11]_i_1_n_0\
    );
\delay_cnt[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[5]\,
      I1 => in5(12),
      I2 => \FSM_onehot_state_reg_n_0_[6]\,
      O => \delay_cnt[12]_i_1_n_0\
    );
\delay_cnt[13]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(13),
      O => \delay_cnt[13]_i_1_n_0\
    );
\delay_cnt[14]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(14),
      O => \delay_cnt[14]_i_1_n_0\
    );
\delay_cnt[15]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(15),
      O => \delay_cnt[15]_i_2_n_0\
    );
\delay_cnt[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(1),
      O => \delay_cnt[1]_i_1_n_0\
    );
\delay_cnt[2]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(2),
      O => \delay_cnt[2]_i_1_n_0\
    );
\delay_cnt[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[5]\,
      I1 => in5(3),
      I2 => \FSM_onehot_state_reg_n_0_[6]\,
      O => \delay_cnt[3]_i_1_n_0\
    );
\delay_cnt[4]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(4),
      O => \delay_cnt[4]_i_1_n_0\
    );
\delay_cnt[5]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(5),
      O => \delay_cnt[5]_i_1_n_0\
    );
\delay_cnt[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[6]\,
      I1 => in5(6),
      O => \delay_cnt[6]_i_1_n_0\
    );
\delay_cnt[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[5]\,
      I1 => in5(7),
      I2 => \FSM_onehot_state_reg_n_0_[6]\,
      O => \delay_cnt[7]_i_1_n_0\
    );
\delay_cnt[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[5]\,
      I1 => in5(8),
      I2 => \FSM_onehot_state_reg_n_0_[6]\,
      O => \delay_cnt[8]_i_1_n_0\
    );
\delay_cnt[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[5]\,
      I1 => in5(9),
      I2 => \FSM_onehot_state_reg_n_0_[6]\,
      O => \delay_cnt[9]_i_1_n_0\
    );
\delay_cnt_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[0]_i_1_n_0\,
      Q => delay_cnt(0),
      R => rst
    );
\delay_cnt_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[10]_i_1_n_0\,
      Q => delay_cnt(10),
      R => rst
    );
\delay_cnt_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[11]_i_1_n_0\,
      Q => delay_cnt(11),
      R => rst
    );
\delay_cnt_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[12]_i_1_n_0\,
      Q => delay_cnt(12),
      R => rst
    );
\delay_cnt_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[13]_i_1_n_0\,
      Q => delay_cnt(13),
      R => rst
    );
\delay_cnt_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[14]_i_1_n_0\,
      Q => delay_cnt(14),
      R => rst
    );
\delay_cnt_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[15]_i_2_n_0\,
      Q => delay_cnt(15),
      R => rst
    );
\delay_cnt_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[1]_i_1_n_0\,
      Q => delay_cnt(1),
      R => rst
    );
\delay_cnt_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[2]_i_1_n_0\,
      Q => delay_cnt(2),
      R => rst
    );
\delay_cnt_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[3]_i_1_n_0\,
      Q => delay_cnt(3),
      R => rst
    );
\delay_cnt_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[4]_i_1_n_0\,
      Q => delay_cnt(4),
      R => rst
    );
\delay_cnt_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[5]_i_1_n_0\,
      Q => delay_cnt(5),
      R => rst
    );
\delay_cnt_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[6]_i_1_n_0\,
      Q => delay_cnt(6),
      R => rst
    );
\delay_cnt_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[7]_i_1_n_0\,
      Q => delay_cnt(7),
      R => rst
    );
\delay_cnt_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[8]_i_1_n_0\,
      Q => delay_cnt(8),
      R => rst
    );
\delay_cnt_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => delay_cnt_0,
      D => \delay_cnt[9]_i_1_n_0\,
      Q => delay_cnt(9),
      R => rst
    );
dut: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_apb_interface
     port map (
      E(0) => delay_cnt_0,
      \FSM_onehot_state_reg[1]\ => dut_n_6,
      \FSM_onehot_state_reg[6]\(0) => dut_n_5,
      Q(3) => \FSM_onehot_state_reg_n_0_[6]\,
      Q(2) => \FSM_onehot_state_reg_n_0_[5]\,
      Q(1) => \FSM_onehot_state_reg_n_0_[3]\,
      Q(0) => \FSM_onehot_state_reg_n_0_[1]\,
      clk => clk,
      cpu_write_reg(0) => cpu_paddr(13),
      \delay_cnt_reg[0]\ => \FSM_onehot_state[7]_inv_i_4_n_0\,
      \paddr_reg[6]_0\(3) => \cpu_paddr_reg_n_0_[13]\,
      \paddr_reg[6]_0\(2) => \cpu_paddr_reg_n_0_[4]\,
      \paddr_reg[6]_0\(1) => \cpu_paddr_reg_n_0_[3]\,
      \paddr_reg[6]_0\(0) => \cpu_paddr_reg_n_0_[2]\,
      penable_reg_0 => dut_n_0,
      penable_reg_1 => penable_i_1_n_0,
      \psel_reg[1]_0\ => dut_n_1,
      \pwdata_reg[6]_0\(6) => \cpu_wdata_reg_n_0_[6]\,
      \pwdata_reg[6]_0\(5) => \cpu_wdata_reg_n_0_[5]\,
      \pwdata_reg[6]_0\(4) => \cpu_wdata_reg_n_0_[4]\,
      \pwdata_reg[6]_0\(3) => \cpu_wdata_reg_n_0_[3]\,
      \pwdata_reg[6]_0\(2) => \cpu_wdata_reg_n_0_[2]\,
      \pwdata_reg[6]_0\(1) => \cpu_wdata_reg_n_0_[1]\,
      \pwdata_reg[6]_0\(0) => \cpu_wdata_reg_n_0_[0]\,
      pwrite_reg_0 => cpu_write_reg_n_0,
      rst => rst,
      state(1 downto 0) => state(1 downto 0),
      tx_out => tx_out
    );
penable_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8860"
    )
        port map (
      I0 => state(0),
      I1 => state(1),
      I2 => dut_n_1,
      I3 => dut_n_0,
      O => penable_i_1_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clk : in STD_LOGIC;
    rst : in STD_LOGIC;
    rx : in STD_LOGIC;
    tx_out : out STD_LOGIC;
    tx_busy_led : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design1_hw_apb_uart_tb_0_0,hw_apb_uart_tb,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "hw_apb_uart_tb,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst, FREQ_HZ 50000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of rst : signal is "xilinx.com:signal:reset:1.0 rst RST";
  attribute X_INTERFACE_PARAMETER of rst : signal is "XIL_INTERFACENAME rst, POLARITY ACTIVE_HIGH, INSERT_VIP 0";
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_hw_apb_uart_tb
     port map (
      clk => clk,
      rst => rst,
      tx_busy_led => tx_busy_led,
      tx_out => tx_out
    );
end STRUCTURE;
